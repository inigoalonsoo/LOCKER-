# CLAUDE.md — Sistema Locker Instrumentacion GHI

> **START HERE — Para el desarrollador que retoma este proyecto**
>
> Este repositorio contiene el sistema de monitoreo automatico del locker ACTUM EPI de GHI Hornos Industriales. Lee esta seccion antes de tocar nada.
>
> **Estado a 2026-09-07: SISTEMA REPARADO Y VERIFICADO. Quedan pendientes de PREVENCION — lee la ultima seccion.**
>
> Hubo un incidente grave (bucle de reprocesado que inflo `HistorialCompleto.csv` a 103.494 filas con solo 187 unicas). **Ningun movimiento se perdio**: la ultima identificacion real es del `2026-07-16 13:20:21` y entre el 17/07 y el 07/09 no hubo ninguna (vacaciones).
>
> **Resuelto:** causa raiz corregida (`MonitoreoLockerTiempoReal.ps1:436`, `Sort-Object` alfabetico sobre fechas `MM/dd/yyyy` que dejaba el marcador atrapado en diciembre) · **v2.4 desplegada** con hash verificado · CSV reconstruido desde SQL a **528 movimientos** con el historico completo desde 26/10/2024 · 5 tareas corriendo · verificado que la tarea corre cada minuto **sin volver a escribir el CSV**.
>
> **⚠️ Lo que NO esta resuelto:** el disparador fueron **7 apagones sucios en 5 semanas**, y el PC estuvo **~19 dias muerto sin que nadie se enterase**. Pendiente: **alerta de sistema caido** y **BIOS que arranque tras corte de corriente**. Ver `## Resumen de Sesion — 2026-09-07`.
>
> **Estado a 2026-06-11 (ultimo estado sano conocido):** Sistema completamente funcional en produccion. 528+ movimientos registrados. 5 tareas programadas activas en GHI-TAQUILLAS. Bug raiz de eventos perdidos RESUELTO (Group-Object → hashtable en PASO 4).
>
> **Las tres cosas mas importantes:**
> 1. El unico script que se edita para cambiar el dashboard es `GenerarDashboard.ps1`. Los demas no hace falta tocarlos salvo que cambie la infraestructura.
> 2. No hay acceso directo por red al locker. El unico camino para desplegar es: copiar el script → enviarlo al PC del locker → pegarlo en Notepad via TeamViewer → guardar en `C:\ACTUM\`.
> 3. Nunca modificar manualmente `HistorialCompleto.csv`, `UltimoEventoProcesado.txt` ni `EstadoAnterior.json`.
>
> **Pendiente prioritario:** El usuario mostrado en "En uso por X" puede diferir del asignado en ACTUM cuando la asignacion se hace desde el software sin abrir el locker fisicamente. Solucion: leer `Consigna.Usuario_Codigo` directamente en `GenerarDashboard.ps1` para la pestana Estado.

---

# ⚡ ESTADO ACTUAL Y SIGUIENTE PASO — actualizado 2026-09-08

> **BLOQUE DE TRASPASO.** Si retomas el proyecto en otra sesion, otra terminal u otro modelo (Codex, etc.),
> lee SOLO esto para saber donde estamos. El detalle esta en las secciones `AUDITORIA COMPLETA DE C:\ACTUM`
> y `Resumen de Sesion — 2026-09-08`, al final del documento.

## Contexto minimo en 10 lineas

Sistema de monitoreo del locker ACTUM de GHI. El PC del locker es **GHI-TAQUILLAS** (IP 172.16.5.40),
usuario Windows **`User`**, acceso por **TeamViewer**. Imanolia lo lleva **sola**, no hay respaldo.

Cadena: la electronica **Kerong** (172.16.5.41:23) habla con **`ACTUM_EPI_Gestion.exe`**, que escribe cada
apertura en **SQL Express `GHI-TAQUILLAS\SQLEXPRESS`, BD `Actum_GHI`, tabla `Eventos`**. Nuestros scripts
(en `C:\ACTUM\`, lanzados por tareas programadas cada minuto via wrappers `.vbs`) leen esa tabla, escriben
`HistorialCompleto.csv` y generan `DashboardLocker.html` **dentro de la carpeta local**
`C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\`. **No hay API ni subida**: es el cliente
OneDrive de Windows, autenticado como `fabricacion1@ghifurnaces.com`, quien la sincroniza a SharePoint.

**El eslabon debil es ese ultimo tramo:** si la contrasena de `fabricacion1` caduca (~cada 50 dias), los
scripts siguen funcionando y **nadie ve nada nuevo en la web**, sin ningun error en ningun log.

## Situacion a 08/09/2026

- **El locker esta FUERA DE SERVICIO a proposito.** Inigo tiene `ACTUM_EPI_Gestion.exe` **cerrado** mientras
  se arregla todo; lo reabrira al terminar. Ultimo evento en SQL: `2026-09-03 12:37:30`.
- **Ultima identificacion de usuario real: `2026-07-16 13:20:21`.** Nadie usa el locker desde julio.
- **CSV sano:** 528 movimientos · 53.562 bytes · ratio filas/unicas **1,00** · marcador
  `2026-07-16 13:20:21`. El bucle de reprocesado del incidente del 07/09 esta **muerto** (v2.4 desplegada).
- **8 cortes de corriente en 5 semanas.** Causa probable dicha por Inigo: **el cuadro electrico del locker
  se cae**. El PC **no vuelve solo** tras un corte (12 h muerto el 07-08/09; 6 dias en agosto).

### Hecho y verificado el 08/09

| Accion | Verificacion |
|---|---|
| `ReconstruirCSVSemanal` desactivada (borraba las correcciones manuales cada lunes) | `State = Disabled` |
| `GenerarDashboardHTML` devuelta a `Disabled` (se encendio sin querer) | `State = Disabled` |
| Suspension, hibernacion e inicio rapido desactivados | `powercfg /a` |
| Watchdog mentiroso eliminado de `GenerarDashboard.ps1` | 0 errores sintaxis · 706 lineas · HTML byte-identico |
| Copia de conflicto de OneDrive borrada (10,4 MB) | listado vacio |
| Hardware descartado | SSD `Healthy` · `NoErrorsFound` · 0 WHEA · 7,9 GB RAM |
| Los 4 `.vbs` activos respaldados en el repo | los 4 `IDENTICO` |

## PENDIENTE — por orden

### Urgente (para volver a poner el locker en servicio)

1. [HECHO 08/09 - **32/32 OK, el dashboard dice la verdad**, ver apartado M] ~~Auditar que el dashboard dice la VERDAD.~~ Comparar consigna a consigna el HTML contra
   `Consigna.Estado` de SQL. **Importante:** la pestana Estado **NO lee SQL**, deriva el estado de la ultima
   accion del CSV (`GenerarDashboard.ps1:174-181`), asi que si el CSV esta mal, **miente**. Bloque de
   auditoria preparado (integridad CSV + HTML + comparacion con SQL). Aqui se cierra tambien lo de la
   **consigna 22 / SERGIO V. VEGA**.
2. [HECHO 08/09 - **LA WEB RECIBE**. El dashboard en SharePoint mostraba *Ultima actualizacion: 2026-09-08 10:24:08*, en hora. OneDrive.exe corriendo (PID 9364 desde las 07:59:50). **La contrasena de fabricacion1 aguanta, no hubo que re-autenticar**] ~~Comprobar que OneDrive sincroniza.~~ Test de 10 s: mirar la hora de *"Ultima actualizacion"* del
   dashboard **en la web** y compararla con la del fichero en el locker. Si el local esta fresco y el de la
   web viejo -> re-autenticar (icono OneDrive -> Configuracion -> pestana **Cuenta**; si se queda en
   "Buscando cambios...", cerrar y reabrir OneDrive). **La contrasena caducaba ~26/08 y no consta
   re-autenticada.**
3. [ARRANQUE AUTOMATICO HECHO 08/09 - acceso directo creado y verificado leyendo el propio .lnk: apunta al exe y el destino existe. Se estrenara en el reinicio de la BIOS] **Reabrir `ACTUM_EPI_Gestion.exe`.** Hoy **no arranca solo**
   (`Win32_StartupCommand` vacio). Sin esto, cada corte de luz deja el locker sin registrar hasta que
   alguien lo abra a mano — y **lo que no se graba no se recupera de ningun sitio**.
4. **BIOS: `Restore on AC Power Loss -> Power On`.** Lo unico que hace que el PC vuelva solo tras un corte.
   Exige reiniciar con alguien delante.
5. [HECHO 08/09 - desplegados y verificados: 246 y 76 lineas, 0 no-ASCII, 0 errores de sintaxis; 4 correcciones guardadas con fechas legibles y tildes correctas. `ReconstruirHistorial.ps1` copiado pero NO ejecutado a proposito: el CSV esta sano y no se toca lo que funciona] ~~Desplegar los dos scripts~~ al locker,
   y ejecutar el segundo una vez. Ver apartado N: hace que las correcciones a mano sobrevivan a las
   reconstrucciones.
6. **Prueba funcional real** (tarea A del 07/09): bajar, sacar un instrumento y devolverlo. Predicado:
   **1 solo movimiento** por accion fisica (ojo al dedup `$ventanaSeg = 3` y a los pares de eventos
   10000+10001), usuario y accion correctos, marcador avanzado a hoy en formato `yyyy-MM-dd HH:mm:ss`,
   y reflejado en el dashboard en < 1 min. **El sistema reparado NO esta probado con un movimiento nuevo.**

### No urgente (para cuando se pregunte "que mas se puede mejorar")

6. **Limpieza de `C:\ACTUM`** — apartado G de la auditoria. 118 ficheros / 98 MB -> ~12 ficheros.
   Mover a `_ARCHIVO\`, **sin borrar**, salvo 3 excepciones. **NO mover ningun script activo**: sus rutas
   estan cableadas en 5 `.vbs` y 5 tareas programadas.
7. **Commitear el repo.** Pendiente de OK de Imanolia: `CLAUDE.md`, `MonitoreoLockerTiempoReal.ps1` (v2.4),
   `GenerarDashboard.ps1` (sin watchdog), `EjecutarMonitoreoOculto.vbs` + 3 `.vbs` nuevos.
8. **Alerta de sistema caido** — aparcada por decision de Inigo ("estoy atento cada 2 por 3"), no descartada.
   El vigilante **debe correr FUERA del locker**: uno que corra dentro no puede avisar de que el PC esta
   muerto, que es justo lo que paso 12 h y 6 dias.
9. **Leer `Consigna.Usuario_Codigo` para la pestana Estado** (pendiente desde el 20/05). Mas importante de
   lo que parecia: hoy **toda** la columna Estado sale del CSV en vez de la fuente de verdad.
10. **Quitar el `<script>`** de `GenerarDashboard.ps1:672-684` (banner rojo de SharePoint por `replaceState`).
    Confirmar antes que el error que ve Inigo es ese y no otro (tarea D).
11. **Renombrar las trampas de datos del repo** (`HistorialCompleto.csv` de feb-2026, `DashboardLocker.html`
    del 18/02) con sufijo `_MUESTRA_2026-02`.
12. **Auditoria fisica de consignas** (tarea B del 07/09) y **calibraciones** (tarea C, recurrente).
13. **De raiz: quitarse la dependencia de OneDrive + `fabricacion1`.** Alternativas estudiadas el 20/05 y
    aun validas: **Microsoft Graph con App Registration + certificado** (no caduca nunca, sin coste, GHI ya
    tiene Entra ID) o **IIS local** en `http://172.16.5.40` (pendiente verificar si las oficinas alcanzan
    esa subred).
14. **Usar el AUTO-UPDATE que ya existe** en `GenerarDashboard.ps1:6-21`: si aparece una version mas nueva
    del script en la carpeta de OneDrive, el locker se la copia y se relanza solo. **Canal de despliegue sin
    TeamViewer que nadie esta usando.**

## Reglas que mas duelen si se olvidan

1. **`Sort-Object` sobre fechas `MM/dd/yyyy` ordena ALFABETICAMENTE.** Parsear siempre primero. Ha causado
   dos incidentes graves (30/04 y 07/09).
2. **Nunca declarar exito sin releer el estado del sujeto.** `rc=0` y un `Write-Host` no son evidencia.
   Ejemplo del 08/09: `powercfg /hibernate off` "se aplico" y `powercfg /a` demostro que no.
3. **`Enable-`/`Disable-ScheduledTask` exigen ADMINISTRADOR.** En ventana normal fallan en silencio.
4. **Literales de fecha en SQL: SIEMPRE `'YYYYMMDD'`.** El servidor esta en espanol y `'2026-07-16'` se lee
   como ano-dia-mes.
5. **Un Event ID sin `ProviderName` no significa nada.** `11` y `153` son de disco en `disk`/`storahci` y
   otra cosa distinta en `Kernel-General`/`Kernel-Boot`.
6. **Ratio filas/unicas del CSV** es el detector barato del bucle: sano ~1,00; el 07/09 era ~600.
7. **Desplegar por copia-pega es viable** si el `.ps1` es **ASCII puro** y se verifica (lineas · no-ASCII ·
   sintaxis · salida byte-identica). Los 5 activos son ASCII puro.
8. **No usar here-strings al pegar por chat/TeamViewer**: la indentacion los rompe. Usar arrays con `-join`.
   Ese fallo dejo `EjecutarReconstruccionOculto.vbs` roto **desde el 20/05, sin que nadie lo notara**.

---

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Project Is

Automated monitoring system for the ACTUM EPI locker at GHI Hornos Industriales. It polls a SQL Server database every minute, detects locker open/close events, appends them to a CSV history, and generates a live HTML dashboard synced via OneDrive.

## Two Environments

**Development** (machine `ialopez`):
- Working folder: `C:\Users\ialopez\OneDrive - GHI HORNOS INDUSTRIALES S.L\TRABAJOS REALIZADOS\LOCKER INSTRUMENTACION\`
- No SQL Server access — scripts cannot be run end-to-end locally
- Server documental folder structure (handover package):
  - `DESARROLLO LOCKER (lo necesario para poder desarrollar el sistema si hace falta)` — source code, scripts, CLAUDE.md
  - `GITHUB REPOSITORIO` — link/reference to https://github.com/inigoalonsoo/LOCKER-.git
  - `INFORMACION LOCKER (lo que hay que saber sobre el sistema)` — DOCUMENTACION_LOCKER.html
  - `MANTENIMIENTO LOCKER (el unico mantenimiento manual que necesita)` — maintenance doc
  - `DashboardLocker` / `DashboardAdmin` — Windows shortcuts (.url) to the live dashboards

**Production** (locker machine — `GHI-TAQUILLAS`):
- Scripts deployed to: `C:\ACTUM\`
- SQL Server: `GHI-TAQUILLAS\SQLEXPRESS`, database `Actum_GHI`
- Dashboard and data: `C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\`
- Access via TeamViewer only (through a colleague who connects remotely)
- Only one Windows user exists on the locker: `User` (not `fabricacion1`, not `User2`)

## Deployment Workflow (ALWAYS follow this)

1. **Claude generates/updates `GenerarDashboard.ps1`** here in development
2. **User copies the script content** (Ctrl+A → Ctrl+C in VS Code)
3. **User sends it to their colleague** who has TeamViewer open to the locker
4. **Colleague opens Notepad on the locker**, pastes the content, saves as `C:\ACTUM\GenerarDashboard.ps1` (encoding: UTF-8, type: All Files)
5. **Colleague runs in locker PowerShell:**
   ```powershell
   cd C:\ACTUM
   .\GenerarDashboard.ps1
   ```
6. **Dashboard updates automatically** — `DashboardLocker.html` is synced via OneDrive to `fabricacion1@ghifurnaces.com`

> ⚠️ There is NO direct network access to the locker from the dev machine. Do NOT try to copy files over the network or use remote PowerShell. The only path is Notepad via TeamViewer.

## Real-Time Data Protocol

Claude must always work with real locker data. If any data is needed:
- Ask for the specific PowerShell command to run on the locker
- The user runs it in the locker PowerShell and pastes the output back
- Claude updates the script based on the real output

**Key data files on the locker:**
- `C:\ACTUM\EXPORT_Cajas.txt` — maps Consigna numbers to instrument codes (L-010, C-002, etc.)
- `C:\ACTUM\EXPORT_Consignas.txt` — consigna details
- `C:\ACTUM\EXPORT_Usuarios.txt` — user list
- `C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\HistorialCompleto.csv` — full movement history (delimiter `;`, UTF-8)
- `C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\EstadoAnterior.json` — last known state

## Script Roles — Qué modificar y qué NO tocar

### ✅ EL ÚNICO SCRIPT QUE SE MODIFICA: `GenerarDashboard.ps1`

Para cambiar el dashboard (diseño, columnas, colores, datos mostrados) **solo se toca `GenerarDashboard.ps1`**. Los demás NO hace falta modificarlos nunca salvo que cambie la infraestructura del locker.

| Script | ¿Se modifica? | Qué hace |
|--------|--------------|----------|
| `GenerarDashboard.ps1` | ✅ **SÍ** | Lee CSV → Genera el HTML del dashboard |
| `MonitoreoLockerTiempoReal.ps1` | ✅ **SÍ** | v2.0: Lee tabla Eventos de SQL → actualiza CSV → llama a GenerarDashboard. **Recupera TODO aunque el PC se apague.** |
| `MoverArchivosOneDrive.ps1` | ❌ **NO** | Mueve archivos al OneDrive |
| `ExportarLocker.ps1` | ❌ **NO** | Exporta datos de SQL a los EXPORT_*.txt |
| `ConfigurarTareaOcultaVBS.ps1` | ❌ **NO** | Configura la tarea programada (ya está hecho, no volver a tocar) |
| `EjecutarMonitoreoOculto.vbs` | ❌ **NO** | Wrapper que lanza PowerShell sin ventana visible |

## Ficheros autogenerados — NO tocar manualmente

- **`HistorialCompleto.csv`** — Lo escribe `MonitoreoLockerTiempoReal.ps1` cada vez que detecta un movimiento en el locker. Es la fuente de datos del dashboard. **No modificar a mano.**
- **`UltimoEventoProcesado.txt`** — Marcador con el timestamp del último evento de la tabla Eventos procesado. Lo usa v2.0 para saber dónde continuar. **No modificar a mano.**
- **`EstadoAnterior.json`** — Lo usa `MonitoreoLockerTiempoReal.ps1` para comparar el estado actual con el anterior y detectar cambios (backward compatibility). **No modificar a mano.**
- **`DashboardLocker.html`** — Lo genera `GenerarDashboard.ps1` automáticamente. **No modificar a mano.**
- **`EXPORT_*.txt`** — Los genera `ExportarLocker.ps1` exportando desde SQL. Se ejecuta manualmente cuando hay que actualizar el mapa de códigos.

## Data Flow (v2.0 - Activo desde 2026-04-21)

```
SQL Server (Actum_GHI)
  └─ Tabla Eventos (Evento=10000 = usuario identificado)
       └─ MonitoreoLockerTiempoReal.ps1 v2.0 (every 1 min via Scheduled Task → VBS)
            ├─ Lee UltimoEventoProcesado.txt (marcador)
            ├─ Query: SELECT * FROM Eventos WHERE Evento=10000 AND FechaHora > @marcador
            ├─ State tracking: determina Extracción/Devolución por estado previo
            ├─ Appends to HistorialCompleto.csv (delimiter: ;, UTF-8)
            ├─ Actualiza UltimoEventoProcesado.txt
            ├─ Health check: OneDrive corriendo?
            └─ SIEMPRE llama a: . "C:\ACTUM\GenerarDashboard.ps1"
                 └─ Reads CSV + SQL (Caja) → builds DashboardLocker.html → OneDrive sync
```

**Ventaja v2.0:** CERO pérdida de datos. Aunque el PC se apague 24 horas, al volver a encender recupera TODOS los eventos de la tabla Eventos.

## State Mapping (ACTUM database values)

- `Consigna.Estado = 2` → "Libre" → logged as `Accion = "Devolución"`
- `Consigna.Estado = 4` → "Ocupada" → logged as `Accion = "Extracción"`
- `Consigna.EstadoPuerta = 2` → "Cerrada", else "Abierta"

## EXPORT_Cajas.txt Structure (key for Código column)

The file `C:\ACTUM\EXPORT_Cajas.txt` has TWO sections separated by a blank line:

**Section 1 — Instruments/Boxes:**
```
Codigo,CodigoCliente,Descripcion,...
1,M-001,Nivel Optico / LeicaNA730Plus / 2201660,...
2,C-002,Cámara Termográfica / TESTO 872 / 87262826812,...
11,L-010,Pinza amp. 1500A / FLUKE 393 / 59260351WS,...
```

**Section 2 — Consignas (lockers):**
```
Codigo,CodigoCliente,Bloque,Fila,Columna,Caja_Codigo,...
1,01,...,1,...   ← consigna "01" holds box Codigo=1 (M-001)
2,02,...,2,...   ← consigna "02" holds box Codigo=2 (C-002)
11,11,...,11,... ← consigna "11" holds box Codigo=11 (L-010)
```

**Lookup logic — CONFIRMED WORKING (2026-02-19):**
- Section 2 (consignas) is EMPTY in the real file — only section 1 has data
- The Consigna number in HistorialCompleto.csv maps DIRECTLY to Codigo in section 1
- IMPORTANT: CSV stores consignas with leading zeros (`"01"`, `"09"`) but EXPORT_Cajas has no zeros (`"1"`, `"9"`)
- Fix: `$consignaKey = "$([int]$mov.Consigna)"` strips the leading zero before lookup
- Consigna `"100"` is a system event — always filter it out with `Where-Object { $_.Consigna -ne '100' }`

## UTF-8 / Tildes Solution (CONFIRMED WORKING ✅)

**Problem:** PowerShell 5.1 reads `.ps1` files as ANSI/Windows-1252 by default, so Spanish characters (á, é, ó, ú, ñ, etc.) inside heredocs (`@"...`"@`) get corrupted when written to HTML.

**Solution applied and confirmed working:**
1. Use **HTML entities** for ALL accented characters inside heredocs:
   - `á` → `&aacute;`, `é` → `&eacute;`, `ó` → `&oacute;`, `ú` → `&uacute;`
   - `Á` → `&Aacute;`, `É` → `&Eacute;`, `Ó` → `&Oacute;`, `Ú` → `&Uacute;`
   - `ñ` → `&ntilde;`, `Nº` → `N&ordm;`
2. Save the `.ps1` with **UTF-8 WITH BOM** (`New-Object System.Text.UTF8Encoding $true`)
3. The `<meta charset="UTF-8">` tag ensures the browser renders entities correctly

> ⚠️ NEVER use raw Spanish characters inside `@"...`"@` heredocs in PowerShell scripts. Always use HTML entities.

## Tab Navigation (CONFIRMED WORKING ✅)

Los tabs usan **CSS puro con radio buttons** — sin JavaScript. Esto es necesario porque OneDrive web (SharePoint preview) bloquea JS.

```html
<input type="radio" class="tab-inputs" id="tab-estado" name="tabs" checked>
<input type="radio" class="tab-inputs" id="tab-historial" name="tabs">
<div class="tabs-nav">
    <label class="tab-label" for="tab-estado">Estado Instrumentos</label>
    <label class="tab-label" for="tab-historial">Historial Movimientos</label>
</div>
```

El CSS activa el tab seleccionado con `#tab-estado:checked ~ .tab-content.content-estado { display: block; }`.

> ⚠️ NUNCA usar JavaScript `onclick` para los tabs — OneDrive web lo bloquea. Siempre CSS puro.

> ⚠️ NUNCA usar `@import url('https://fonts.googleapis.com/...')` — OneDrive web bloquea CDN externos. Usar fuentes del sistema: `-apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif`

## Known Issues / Pending

**1. Date format mismatch (MEDIUM)**
`GenerarDashboard.ps1` parses dates with `'MM/dd/yyyy HH:mm:ss'` (US format). The locker machine may write dates in Spanish format (`dd/MM/yyyy`). A format mismatch silently corrupts `Sort-Object`. If instrument states look wrong, check the date format in the real CSV first.

**2. Consignas con cero inicial (✅ RESUELTO)**
El CSV almacena consignas como `"01"`, `"02"` etc. pero EXPORT_Cajas.txt usa `"1"`, `"2"` sin cero. Fix aplicado: `$consignaKey = "$([int]$mov.Consigna)"` convierte `"01"` → `"1"` antes del lookup.

**3. Tarea programada falla por SQL (MITIGADO)**
`MonitoreoLockerTiempoReal.ps1` a veces falla al conectar con SQL Server (error 2147946720) y no llega a llamar a `GenerarDashboard.ps1`. Solución: se creó una segunda tarea `GenerarDashboardHTML` que ejecuta **solo** `GenerarDashboard.ps1` cada minuto como respaldo.

## Useful Manual Commands (run on locker machine)

```powershell
# Regenerate dashboard from existing CSV
cd C:\ACTUM
.\GenerarDashboard.ps1

# Check first 5 lines of CSV to see real data format
Get-Content "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\HistorialCompleto.csv" | Select-Object -First 5

# Check scheduled task status
Get-ScheduledTaskInfo -TaskName "MonitoreoLockerTiempoReal" | Select-Object LastRunTime, LastTaskResult, NextRunTime

# Verify script version in production
Get-Item "C:\ACTUM\GenerarDashboard.ps1" | Select-Object Length, LastWriteTime
Get-Content "C:\ACTUM\GenerarDashboard.ps1" | Select-Object -First 5

# Check HTML was generated correctly
Get-Item "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\DashboardLocker.html" | Select-Object Length, LastWriteTime
```

## Corporate Identity

- Primary red: `#C31E2E`
- Logo: embedded SVG (inline in dashboard heredoc, no external file dependency)
- Font: **system fonts only** (`-apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif`) — NO Google Fonts CDN
- Design: dark glassmorphism, gradient badges (green=Disponible, red=En uso/Extracción)
- Stats grid: always 4 columns (`grid-template-columns: repeat(4, 1fr)`)
- Table headers: `white-space: nowrap` to prevent wrapping
- NO `setTimeout` auto-reload — el HTML lo actualiza la tarea programada cada minuto

## Estado Actual del Dashboard (confirmado 2026-02-24) ✅

Características CONFIRMADAS funcionando en producción:

| Característica | Estado | Detalle |
|---|---|---|
| Diseño dark glassmorphism | ✅ | Fondo negro/gris, tarjetas translucidas |
| Logo GHI SVG inline | ✅ | Sin dependencias externas |
| 4 stat cards en una fila | ✅ | `repeat(4, 1fr)` |
| Pestaña Estado Instrumentos | ✅ | CSS puro, radio buttons |
| Pestaña Historial Movimientos | ✅ | CSS puro, radio buttons |
| Tildes y caracteres españoles | ✅ | HTML entities en heredoc + normalización Accion |
| Columna Código (L-010, T-001...) | ✅ | Desde SQL tabla `Caja` (auto-actualizado) |
| Columna Instrumento / Modelo / Nº serie | ✅ | Desde `Caja.Descripcion` en SQL |
| Consignas con cero (01, 09...) | ✅ | Fix `[int]` para strip leading zero |
| Filtro consigna 100 (sistema) | ✅ | `Where-Object { $_.Consigna -ne '100' }` |
| Badges verde/rojo estado | ✅ | Disponible / En uso por [nombre] |
| "En uso por " sin nombre | ✅ | Muestra solo "En uso" si usuario vacío |
| Duplicados en historial | ✅ | Group-Object sin Accion (encoding distinto) |
| Tildes en Extracción/Devolución | ✅ | Normalizado a `Extracci&oacute;n` / `Devoluci&oacute;n` |
| Actualización automática | ✅ | Doble tarea: MonitoreoLocker + GenerarDashboardHTML |
| Auto-actualización desde ACTUM EPI Visor | ✅ | SQL directo cada minuto — sin EXPORT manual |
| Compatible OneDrive web | ✅ | Sin JS, sin CDN externos |
| Nº Consigna en una línea | ✅ | `white-space: nowrap` en `th` |

---

## MonitoreoLockerTiempoReal.ps1 v2.0 — Sistema basado en Eventos (2026-04-21)

**Cambio arquitectónico mayor:** El script ahora usa la tabla `Eventos` de SQL como fuente de datos, en lugar de comparar estados. Esto garantiza **CERO pérdida de datos**.

### Tabla Eventos (SQL)

| Campo | Descripción |
|---|---|
| `Codigo` | GUID único del evento |
| `FechaHora` | Timestamp exacto del evento |
| `Evento` | Tipo: 3=puerta cierra, 4=puerta abre, **10000=usuario identificado** |
| `Consigna_Codigo` | Número de consigna |
| `Caja_Codigo` | Número de caja/instrumento |
| `Usuario_Codigo` | Código del usuario (solo en Evento=10000) |
| `Tratado` | Flag de procesado (no lo usamos) |

**Total eventos:** 168.760 desde 26/10/2024 hasta la actualidad.

### Cómo funciona v2.0

1. **Lee `UltimoEventoProcesado.txt`** → timestamp del último evento procesado
2. **Query SQL:** `SELECT * FROM Eventos WHERE Evento=10000 AND FechaHora > @ultimo`
3. **State tracking:** Para cada evento, determina si es Extracción o Devolución según el estado previo de la consigna:
   - Estado Ocupada (4) → acceso → Libre (2) = **Extracción**
   - Estado Libre (2) → acceso → Ocupada (4) = **Devolución**
4. **Añade al CSV** con el mismo formato que v1.0
5. **Actualiza `UltimoEventoProcesado.txt`**

### Ventajas vs v1.0

| Característica | v1.0 (antiguo) | v2.0 (nuevo) |
|---|---|---|
| Fuente de datos | Comparar `FechaHoraUltimaApertura` | **Tabla Eventos** |
| Pérdida de datos | Sí (si alguien saca+devuelve durante parada) | **No** |
| Recuperación tras apagado | Solo estado final | **TODOS los eventos** |
| Health check OneDrive | No | **Sí** |
| Fallback si SQL falla | No | **Sí** (usa método v1.0) |

### Fichero de marcador

**`UltimoEventoProcesado.txt`** - Contiene el timestamp del último evento procesado (formato: `yyyy-MM-dd HH:mm:ss`)

- En primera ejecución: lee última línea del CSV, resta 10 segundos (ventana de solapamiento)
- En ejecuciones normales: solo procesa eventos nuevos desde el marcador
- Se actualiza después de cada ejecución

### Fallback automático

Si la tabla `Eventos` no está disponible o la query falla, el script **automáticamente usa el método v1.0** (comparación de estados) como fallback. Esto garantiza que el sistema nunca se pare completamente.

---

## DashboardAdmin.html — Panel Interno (creado 2026-02-26)

Dashboard paralelo al DashboardLocker.html, para uso exclusivo de los administradores del sistema.
**NO interfiere con el DashboardLocker.html ni con ningún script existente.**

### Archivos nuevos:
| Archivo | Ruta dev | Ruta locker |
|---|---|---|
| `GenerarDashboardAdmin.ps1` | `GHI/GenerarDashboardAdmin.ps1` | `C:\ACTUM\GenerarDashboardAdmin.ps1` |
| `EjecutarAdminOculto.vbs` | `GHI-Locker-Dashboard/tareas-programadas/EjecutarAdminOculto.vbs` | `C:\ACTUM\EjecutarAdminOculto.vbs` |
| `DashboardAdmin.html` | (generado automáticamente) | `C:\Users\User\OneDrive...\LockerACTUM\DashboardAdmin.html` |

### Estructura del dashboard:
- **Pestaña 1 — Registro de Uso**: Recuento de usos por instrumento desde CSV, ordenado de mayor a menor. Barras visuales de uso, ranking con medallas (oro/plata/bronce), fecha último uso.
- **Pestaña 2 — Calibración**: Todos los instrumentos con FechaCaducidad de SQL. Badge CADUCADO/URGENTE(<30d)/PRÓXIMO(<90d)/CALIBRADO/SIN FECHA. Barra de progreso de días restantes. Ordenado por urgencia.
- **Pestaña 3 — Usuarios**: Lista completa desde SQL tabla Usuario. Columnas: `CodigoCliente` (código visible tipo "0001"), `UID` (PIN de acceso al locker), `Nombre`, `Apellidos`, tipo de acceso (SAT/Estándar). Ordenado por CodigoCliente.

### Banner de alerta automático:
Si hay instrumentos caducados o urgentes, aparece un banner rojo en la parte superior indicándolo.

### Tarea programada para el Admin Dashboard:
```powershell
# Ejecutar como admin en el locker para crear la tarea:
$accion = New-ScheduledTaskAction -Execute "wscript.exe" -Argument "`"C:\ACTUM\EjecutarAdminOculto.vbs`""
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration ([System.TimeSpan]::FromDays(3650))
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
Register-ScheduledTask -TaskName "GenerarDashboardAdmin" -Action $accion -Trigger $trigger -Principal $principal -Settings $settings
```
> Nota: se actualiza cada 1 min, igual que el DashboardLocker principal.

### Pasos de despliegue (estado 2026-03-10):
1. ✅ Copiar `GenerarDashboardAdmin.ps1` al locker como `C:\ACTUM\GenerarDashboardAdmin.ps1`
2. ✅ Copiar `EjecutarAdminOculto.vbs` al locker como `C:\ACTUM\EjecutarAdminOculto.vbs`
3. ✅ Ejecutar el script para generar el HTML inicial: `cd C:\ACTUM; .\GenerarDashboardAdmin.ps1`
4. ✅ Verificar que `DashboardAdmin.html` aparece en `C:\Users\User\OneDrive...\LockerACTUM\` — CONFIRMADO FUNCIONANDO
5. ✅ **COMPLETADO 2026-03-10**: Tarea programada `GenerarDashboardAdmin` creada — State: Ready, NextRunTime cada 1 min

### Columnas SQL confirmadas — Tabla `Usuario` (2026-02-26)

> ⚠️ IMPORTANTE: Los nombres reales difieren de lo esperado:

| Columna SQL real | Lo que muestra | Ejemplo |
|---|---|---|
| `CodigoCliente` | Código visible en ACTUM EPI Visor | `0001`, `0002` |
| `UID` | PIN de acceso al locker (lo que el usuario teclea) | `71102524`, `79002926` |
| `Nombre` | Nombre del usuario | `RAUL V.` |
| `Apellidos` | Apellidos | `VILLASANTE` |
| `AccesoConsignasRestringidas` | `True` = SAT (acceso total) | |
| `Codigo` | ID interno numérico (1, 2, 3...) — NO usar para mostrar | |

**NUNCA usar `Pin` — esa columna NO existe. El PIN es `UID`.**
**NUNCA usar `Codigo` para el código visible — usar `CodigoCliente`.**

## Resumen de Sesión — 2026-02-26 (tarde)

### Todo lo completado en esta sesión:

**1. DashboardAdmin.html — CREADO Y FUNCIONANDO EN PRODUCCIÓN ✅**
- Generado por `GenerarDashboardAdmin.ps1` en `C:\ACTUM\`
- HTML en `C:\Users\User\OneDrive...\LockerACTUM\DashboardAdmin.html`
- Pestaña 1 (Registro de Uso) ✅ funcionando
- Pestaña 2 (Calibración) ✅ funcionando
- Pestaña 3 (Usuarios) ✅ funcionando tras fix de columnas SQL

**2. Fix columnas SQL Usuarios (bug crítico resuelto)**
- `Pin` → renombrado a `UID` (nombre real en la tabla)
- `Codigo` → renombrado a `CodigoCliente` (para el código visible tipo "0001")
- Ordenado por `CodigoCliente` (igual que ACTUM EPI Visor)

**3. Intervalo tarea programada — cambiado a 1 minuto**
- Antes estaba configurado a 5 min → ahora 1 min (igual que DashboardLocker)

**4. VBS wrapper `EjecutarAdminOculto.vbs` — copiado al locker ✅**

### Estado final sistema completo (2026-02-26):
| Componente | Estado | Notas |
|---|---|---|
| `MonitoreoLockerTiempoReal` | ✅ Corriendo | Interactive (User), cada 1 min |
| `GenerarDashboard.ps1` + `DashboardLocker.html` | ✅ Producción | Sin tocar |
| `ActualizarExcel.ps1` | ✅ Corriendo | SYSTEM, cada 5 min |
| `GenerarDashboardAdmin.ps1` + `DashboardAdmin.html` | ✅ Funcionando | HTML generado OK |
| Tarea `GenerarDashboardAdmin` (auto-refresh) | ⏳ PENDIENTE | Crear en próxima sesión |

### Lo que queda por hacer (próxima sesión):
1. **Crear la tarea programada** `GenerarDashboardAdmin` en el locker (ejecutar como admin):
```powershell
$accion = New-ScheduledTaskAction -Execute "wscript.exe" -Argument "`"C:\ACTUM\EjecutarAdminOculto.vbs`""
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration ([System.TimeSpan]::FromDays(3650))
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
Register-ScheduledTask -TaskName "GenerarDashboardAdmin" -Action $accion -Trigger $trigger -Principal $principal -Settings $settings
```

---

## Tareas Pendientes / Posibles Mejoras Futuras

Lista de mejoras a implementar en próximas sesiones:

**DashboardLocker (público):**
- [ ] Ordenar la tabla por Estado (En uso primero, luego Disponible)
- [ ] Añadir buscador/filtro en la tabla de historial
- [ ] Mostrar fecha de último uso de cada instrumento en la tabla de estado
- [ ] Añadir columna "Días en uso" para instrumentos no devueltos

**DashboardAdmin (interno):**
- [ ] Añadir gráfico de uso por usuario (quién usa más el locker)
- [ ] Añadir línea de tendencia de movimientos por semana/mes
- [ ] Filtro de calibración por departamento (si se añade esa columna en SQL)

## Resumen de Sesión — 2026-02-24

### Todo lo completado en esta sesión:

**1. Fix tildes en Historial Movimientos**
- Problema: CSV tenía entradas con encoding roto → `"DevoluciÃ³n"` / `"ExtracciÃ³n"`
- Solución: normalizar siempre el valor de `Accion` a HTML entities en el render:
  ```powershell
  $accionTexto = if ($mov.Accion -like '*Extracci*') { 'Extracci&oacute;n' } elseif ($mov.Accion -like '*Devoluci*') { 'Devoluci&oacute;n' } else { $mov.Accion }
  ```

**2. Fix filas duplicadas en Historial**
- Problema: mismo evento aparecía dos veces con distinto encoding de `Accion` → `Group-Object` los trataba como diferentes
- Solución: quitar `Accion` del `Group-Object` key:
  ```powershell
  Group-Object FechaHoraApertura, Usuario, Consigna  # sin Accion
  ```

**3. Columna renombrada a "Instrumento / Modelo / Nº serie"**
- El campo `Caja.Descripcion` ya viene en ese formato desde SQL (`"Nivel Optico / LeicaNA730Plus / 2201660"`)

**4. Fix "En uso por " sin nombre**
- Si `Usuario` o `Apellidos` están vacíos, muestra `"En uso"` en vez de `"En uso por "`
- Fix aplicado en dos sitios: construcción del objeto y render HTML

**5. Integración SQL directa — GRAN MEJORA**
- `GenerarDashboard.ps1` ahora lee directamente de la tabla `Caja` de SQL Server:
  ```sql
  SELECT Codigo, CodigoCliente, Descripcion, FechaCaducidad FROM Caja
  ```
- `Caja.Codigo` = número de consigna (clave de enlace con el CSV de historial)
- Fallback automático a `EXPORT_Cajas.txt` si SQL no disponible
- `FechaCaducidad` se lee y almacena en los objetos (para uso futuro en HTML de calibración)

**6. Auto-actualización sin EXPORT manual**
- Cualquier cambio en ACTUM EPI Visor (nuevo instrumento, descripción, fecha caducidad...) se refleja en el dashboard en < 1 minuto
- Ya NO necesario hacer export desde ACTUM EPI Visor para actualizar el dashboard

### Estructura tabla SQL Caja (confirmada 2026-02-24):
| Columna SQL | Uso |
|---|---|
| `Codigo` | = Nº Consigna (clave de enlace) |
| `CodigoCliente` | Código GHI (M-001, L-010...) |
| `Descripcion` | "Instrumento / Modelo / Nº serie" (formato ya correcto) |
| `FechaCaducidad` | Fecha caducidad calibración (para futuro HTML) |
| `Foto` | Bytes PNG — ignorar |

### Estado final del sistema (2026-02-24):
| Script | En locker | Funciona | Fuente de datos |
|---|---|---|---|
| `MonitoreoLockerTiempoReal.ps1` | ✅ | ✅ Cada 1 min | SQL → CSV |
| `GenerarDashboard.ps1` | ✅ | ✅ Cada 1 min (VBS) | SQL (Caja) + CSV (Historial) |
| `ActualizarExcel.ps1` | ✅ | ✅ Cada 5 min (VBS) | CSV (Historial) + Excel |

## Resumen de Sesión — 2026-02-19

### Todo lo completado en esta sesión:

**1. Fix columna Código (L-010, T-001...)**
- Problema: `consignasMap` (sección 2 de EXPORT_Cajas.txt) estaba vacía en el locker
- Solución: el número de Consigna del CSV mapea DIRECTAMENTE al Codigo de sección 1
- `$mapaCodigos[$campos[0].Trim()] = $campos[1].Trim()` — directo, sin sección 2

**2. Fix consignas con cero inicial (01, 09...)**
- Problema: CSV guarda `"01"` pero EXPORT_Cajas.txt tiene `"1"` sin cero
- Solución: `$consignaKey = "$([int]$mov.Consigna)"` — convierte `"01"` → `"1"` antes del lookup

**3. Fix "Nº Consigna" en dos líneas**
- Añadido `white-space: nowrap` a todos los `th` de la tabla

**4. Tarea programada `GenerarDashboardHTML` (respaldo anti-fallos SQL)**
- Si `MonitoreoLockerTiempoReal` falla por SQL, el HTML igualmente se regenera cada minuto
- Usaba `-WindowStyle Hidden` que NO ocultaba la ventana → reconfigurada con VBS wrapper

**5. Ventana PowerShell visible cada minuto — RESUELTO**
- `GenerarDashboardHTML` rehecha con `EjecutarDashboardOculto.vbs` (parámetro `0` = 100% oculto)
- Patrón VBS documentado para todas las tareas futuras

**6. Excel de instrumentos — COMPLETADO**
- `ActualizarExcel.ps1` creado y desplegado en `C:\ACTUM\`
- ImportExcel v7.8.10 instalado en ruta no estándar (OneDrive\Documentos\WindowsPowerShell\Modules)
- Fix: `$excel.Save(); $excel.Dispose()` en vez de `Close-ExcelPackage -Save` (falla en v7.8.10)
- Tarea `ActualizarExcelLocker` creada via `EjecutarExcelOculto.vbs`, cada 5 minutos
- Actualiza: col A (UBICACIÓN) y col K (Estado CALIBRADO/CADUCADO)

### Estado final del sistema (2026-02-19 13:10):
| Script | En locker | Funciona |
|---|---|---|
| `MonitoreoLockerTiempoReal.ps1` | ✅ | ✅ Cada 1 min |
| `GenerarDashboard.ps1` | ✅ | ✅ Cada 1 min (VBS) |
| `ActualizarExcel.ps1` | ✅ | ✅ Cada 5 min (VBS) |
| `ExportarLocker.ps1` | ✅ | Manual (cuando cambia el ACTUM) |


## Tareas Programadas en el Locker (2026-02-19)

| Tarea | Qué ejecuta | Frecuencia | Propósito |
|---|---|---|---|
| `MonitoreoLockerTiempoReal` | `EjecutarMonitoreoOculto.vbs` → `MonitoreoLockerTiempoReal.ps1` | Cada 1 min | SQL → CSV → HTML |
| `GenerarDashboardHTML` | `EjecutarDashboardOculto.vbs` → `GenerarDashboard.ps1` | Cada 1 min | Respaldo: HTML siempre actualizado |
| `ActualizarExcelLocker` | `EjecutarExcelOculto.vbs` → `ActualizarExcel.ps1` | Cada 5 min | Actualiza UBICACIÓN y Estado en Excel |

## Cómo hacer tareas programadas 100% invisibles (SIN ventana PowerShell)

> ⚠️ CRÍTICO: Nunca crear tareas que llamen directamente a `powershell.exe` con `-File`. Aunque se use `-WindowStyle Hidden`, Windows a veces muestra la ventana igualmente. La solución correcta es SIEMPRE usar un wrapper VBS.

### Patrón correcto (3 pasos):

**Paso 1 — Crear el VBS wrapper** (hacer invisible la ejecución):
```powershell
Set-Content -Path "C:\ACTUM\EjecutarXXXOculto.vbs" -Value 'CreateObject("WScript.Shell").Run "powershell.exe -WindowStyle Hidden -NonInteractive -ExecutionPolicy Bypass -File ""C:\ACTUM\NombreScript.ps1""", 0, False'
```
El `0` en `.Run` es el parámetro clave — significa "ventana completamente oculta".

**Paso 2 — Crear la tarea apuntando al VBS** (no al .ps1 directamente):
```powershell
$accion = New-ScheduledTaskAction -Execute "wscript.exe" -Argument "`"C:\ACTUM\EjecutarXXXOculto.vbs`""
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration ([System.TimeSpan]::FromDays(3650))
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
Register-ScheduledTask -TaskName "NombreTarea" -Action $accion -Trigger $trigger -Principal $principal -Settings $settings
```

**Paso 3 — Verificar:**
```powershell
Get-ScheduledTask -TaskName "NombreTarea" | Select-Object TaskName, State
```

### Archivos VBS en C:\ACTUM (confirmados funcionando):
| Archivo VBS | Script que lanza |
|---|---|
| `EjecutarMonitoreoOculto.vbs` | `MonitoreoLockerTiempoReal.ps1` |
| `EjecutarDashboardOculto.vbs` | `GenerarDashboard.ps1` |
| `EjecutarExcelOculto.vbs` | `ActualizarExcel.ps1` |

## Excel de Instrumentos — ✅ RESUELTO (2026-02-19)

**Archivo:** `00.Intrumentos_Locker (1).xlsx`
- En locker (User): `C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\00.Intrumentos_Locker (1).xlsx`
- En dev (ialopez): `c:\Users\ialopez\OneDrive - GHI HORNOS INDUSTRIALES S.L\LOCKER INSTRUMENTACIÓN\00.Intrumentos_Locker (1).xlsx`

**Script:** `C:\ACTUM\ActualizarExcel.ps1` — actualiza cada 5 min via tarea `ActualizarExcelLocker`

**Qué actualiza automáticamente:**
- Columna **A (UBICACIÓN)**: `Disponible` o `En uso por [nombre]` según estado del locker
- Columna **K (Estado)**: `CALIBRADO` o `CADUCADO` comparando Fecha caducidad (col I) con hoy

**Detalles técnicos importantes:**
- ImportExcel v7.8.10 instalado en ruta NO estándar: `C:\Users\User\OneDrive...\Documentos\WindowsPowerShell\Modules\ImportExcel\7.8.10\`
- El script lo busca en rutas alternativas automáticamente si `Import-Module ImportExcel` falla
- NO usar `Close-ExcelPackage -Save` — en v7.8.10 falla. Usar `$excel.Save(); $excel.Dispose()`
- Datos empiezan en **fila 3**. CONSIGNA formato: `"Consigna - 1"` → extraer número con regex

**Estructura del Excel (confirmada):**
| Col | Contenido |
|-----|-----------|
| A | UBICACIÓN (auto-actualizada) |
| B | CONSIGNA (formato: "Consigna - 1") |
| C | DEPARTAMENTO |
| D | CODIGO GHI (M-001, L-010...) |
| E | DESCRIPCIÓN |
| F | NUMERO DE SERIE |
| G | MODELO |
| H | Fecha calibración |
| I | Fecha caducidad |
| J | EMP (Error máximo permitido) |
| K | Estado (auto-actualizado: CALIBRADO/CADUCADO) |
| L | EMPRESA |

**Archivo:** `00.Intrumentos_Locker (1).xlsx`
- En dev (ialopez): `c:\Users\ialopez\OneDrive - GHI HORNOS INDUSTRIALES S.L\LOCKER INSTRUMENTACIÓN\00.Intrumentos_Locker (1).xlsx`
- En locker (User): `C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\00.Intrumentos_Locker (1).xlsx`

**Script creado:** `ActualizarExcel.ps1` en `C:\ACTUM\` (ya pasado al locker)

**Qué hace el script (listo, solo falta el módulo):**
- Columna **A (UBICACIÓN)**: actualiza a `Disponible` o `En uso por [nombre]` según el estado del locker
- Columna **K (Estado)**: actualiza a `CALIBRADO` o `CADUCADO` comparando Fecha caducidad (col I) con hoy

**Estructura del Excel (confirmada):**
| Col | Contenido |
|-----|-----------|
| A | UBICACIÓN (LOCKER, PRODUCCION, SAT, En uso por...) |
| B | CONSIGNA (formato: "Consigna - 1", "Consigna - 2"...) |
| C | DEPARTAMENTO |
| D | CODIGO GHI (M-001, L-010, T-001...) |
| E | DESCRIPCIÓN |
| F | NUMERO DE SERIE |
| G | MODELO |
| H | Fecha calibración |
| I | Fecha caducidad |
| J | EMP (Error máximo permitido) |
| K | Estado (CALIBRADO / CADUCADO) |
| L | EMPRESA |

**Datos empiezan en fila 3** (filas 1-2 son título/cabecera).
**CONSIGNA col B** usa formato "Consigna - N" → extraer número con regex `Consigna\s*-\s*(\d+)`.

**Problema bloqueante:** El locker no puede instalar el módulo `ImportExcel` de PowerShell Gallery.
- Se intentó: `[Net.ServicePointManager]::SecurityProtocol = Tls12` + NuGet + `Install-Module ImportExcel -Scope CurrentUser -Force`
- NuGet se instaló (v2.8.5.208) pero `ImportExcel` no se descargó
- **Posible solución futura:** Descargar el módulo en dev (ialopez) y copiarlo manualmente al locker vía OneDrive:
  ```powershell
  # En ialopez: guardar el módulo en una carpeta
  Save-Module -Name ImportExcel -Path "C:\Users\ialopez\OneDrive - GHI HORNOS INDUSTRIALES S.L\LOCKER INSTRUMENTACIÓN\ImportExcel_module"
  # En locker: importar desde esa ruta
  Import-Module "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LOCKER INSTRUMENTACION\ImportExcel_module\ImportExcel\*\ImportExcel.psd1"
  ```

---

## Evaluación de Sostenibilidad del Sistema (2026-02-24) ✅

### Componentes 100% sólidos y permanentes:

| Componente | Por qué es permanente |
|---|---|
| **Tildes** (Extracción/Devolución) | Fix a nivel de código — siempre escribe HTML entities, ignora encoding del CSV |
| **Auto-actualización de instrumentos** | Lectura SQL directa cada minuto — sin EXPORT manual ni pasos intermedios |
| **Compatibilidad OneDrive web** | HTML puro con CSS, sin JS, sin CDN externos — no puede romperse |
| **Deduplicación historial** | Group-Object por fecha+usuario+consigna (sin Accion) — robusto ante cualquier encoding |
| **Tabla Eventos como fuente** | **v2.0**: Recupera TODOS los eventos aunque el PC se apague horas |
| **Health check OneDrive** | **v2.0**: Auto-restart si el proceso se cae |

### Las dependencias del sistema (post v2.0):

| Riesgo | Probabilidad | Impacto si falla | ¿Cubierto? |
|---|---|---|---|
| **SQL Server apagado** (GHI-TAQUILLAS\SQLEXPRESS) | Baja | No se registran eventos nuevos | ⚠️ No hay solución técnica |
| **PC locker se apaga / cierra sesión** | Media | **v2.0**: Recupera TODO al volver | ✅ **RESUELTO** |
| **OneDrive sin conexión** | Baja | HTML se actualiza en local pero no en web | ⚠️ Requiere intervención manual |
| **Expiración contraseña Windows** | Media (cada 50 días) | OneDrive pierde sesión | ⚠️ Requiere login manual (IT) |

### v2.0: Sistema tolerante a fallos

**Antes (v1.0):** Si el PC se apagaba y alguien sacó+devolvió un instrumento, esos movimientos se perdían (solo se veía el estado final).

**Ahora (v2.0):** La tabla `Eventos` registra CADA apertura/cierre con timestamp. Aunque el PC esté apagado 3 días, al volver se recuperan los 3 días completos de eventos.

### ⚠️ PUNTO MÁS DÉBIL: Tareas programadas como Interactive

Las tareas están configuradas con `LogonType Interactive`, lo que significa que **solo corren si hay una sesión de usuario activa** en el PC del locker. Si el PC reinicia o cierra sesión sin que nadie entre, las actualizaciones se detienen.

**Solución definitiva (requiere admin, una sola vez):**
```powershell
# Ejecutar como ADMINISTRADOR en el locker:
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
Set-ScheduledTask -TaskName "GenerarDashboardHTML"       -Principal $principal
Set-ScheduledTask -TaskName "MonitoreoLockerTiempoReal"  -Principal $principal
Set-ScheduledTask -TaskName "ActualizarExcelLocker"      -Principal $principal
```
Con esto las tareas corren 24/7 como servicio del sistema, sin necesitar sesión activa.

### Escalabilidad a largo plazo:

- **CSV creciente:** ~10 mov/día × 365 = ~3.650 entradas/año. El script agrupa y filtra eficientemente. Sin problemas durante al menos 10 años.
- **Mantenimiento necesario:** Prácticamente cero en condiciones normales.
- **Cambios que SÍ requieren intervención futura:**
  - Cambio de nombre/IP del servidor SQL → actualizar `$connStr` en `GenerarDashboard.ps1` y `MonitoreoLockerTiempoReal.ps1`
  - Cambio de ruta de OneDrive en el locker → actualizar `$carpetaUser` al inicio de cada script

---

## Estructura SQL confirmada (2026-02-24) — Para referencia futura

### Tabla `Caja` — Instrumentos del locker
| Columna | Descripción |
|---|---|
| `Codigo` | = Nº Consigna (clave de enlace con historial CSV) |
| `CodigoCliente` | Código GHI (M-001, L-010...) |
| `Descripcion` | "Instrumento / Modelo / Nº serie" (ya formateado correctamente) |
| `FechaCaducidad` | Fecha caducidad calibración (para futuro HTML de calibración) |
| `Foto` | PNG en bytes — ignorar |

### Tabla `Consigna` — Configuración de cada hueco del locker
| Columna | Descripción |
|---|---|
| `Codigo` | Número de consigna |
| `Caja_Codigo` | Instrumento asignado (FK a Caja) |
| `Restringida` | `True` = solo SAT; `False` = accesible a todos |
| `Activa` | Si la consigna está operativa |
| `Usuario_Codigo` | Usuario que tiene el instrumento ahora |

### Tabla `Usuario` — Usuarios del sistema
| Columna | Descripción |
|---|---|
| `AccesoConsignasRestringidas` | `True` = SAT (puede abrir todas); `False` = solo consignas no restringidas |
| `Consigna_Codigo` | Consigna habitualmente asignada al usuario |
| `Nombre`, `Apellidos` | Identificación del usuario |

---

## Resumen Final del Proyecto (estado a 2026-04-21)

El sistema de monitoreo del locker ACTUM está **completamente operativo y automatizado**:

1. **`MonitoreoLockerTiempoReal.ps1` v2.0** (cada 1 min) → Lee tabla Eventos → Escribe CSV → Genera HTML
2. **`GenerarDashboard.ps1`** (cada 1 min, tarea de respaldo) → Lee SQL (Caja) + CSV → Genera HTML
3. **`ActualizarExcel.ps1`** (cada 5 min) → Lee CSV → Actualiza Excel de instrumentos

**Sin intervención manual necesaria para:**
- ✅ Nuevas extracciones/devoluciones → aparecen en < 1 min
- ✅ Cambios de instrumento en ACTUM EPI Visor → aparecen en < 1 min
- ✅ Instrumentos nuevos o eliminados → aparecen en < 1 min
- ✅ Tildes y caracteres especiales → siempre correctos
- ✅ Estado del Excel de instrumentos → actualizado cada 5 min
- ✅ **Recuperación tras apagado** → TODOS los eventos se recuperan al volver (v2.0)

**Estado final confirmado (2026-04-21 — PRODUCCION):**
| Componente | Estado | Notas |
|---|---|---|
| MonitoreoLockerTiempoReal | ✅ v2.0 Interactive (User) via VBS | Oculto, cada 1 min, basado en tabla Eventos |
| GenerarDashboardHTML | ✅ ACTIVA — Interactive (User) | Oculto, cada 1 min |
| GenerarDashboardAdmin | ✅ Interactive (User) via VBS | Oculto, cada 1 min |
| ActualizarExcel | ✅ SYSTEM | OK |
| Auto-login PC locker | ✅ Configurado | AutoAdminLogon=1, User, sin contrasena |
| Watchdog tarea | ✅ Configurado | Reinicia 3 veces si falla |
| Tildes/Codigos | ✅ CORRECTO | M-001, C-002... OK. Tildes OK |
| **Tabla Eventos** | ✅ **Activa** | 168.760 eventos desde oct 2024 |
| **UltimoEventoProcesado.txt** | ✅ **Activo** | Marcador para tracking |

---

## Resumen de Sesión — 2026-04-21 (v2.0 Eventos + v2.1 Dedup + Refresh UX)

### Cambio arquitectónico mayor implementado ✅

**1. MonitoreoLockerTiempoReal.ps1 v2.0**
- **Sistema basado en tabla Eventos** en lugar de comparación de estados
- Query: `SELECT * FROM Eventos WHERE Evento IN (10000, 10001) AND FechaHora > @ultimo`
- **CERO pérdida de datos:** recupera TODO aunque el PC se apague horas
- **State tracking:** alternancia desde estado actual de SQL (fuente de verdad)
- **Health check OneDrive:** auto-restart si el proceso se cae
- **Fallback automático:** si Eventos falla, usa método v1.0

**2. Archivo de marcador**
- `UltimoEventoProcesado.txt` → timestamp del último evento procesado
- En primera ejecución: lee CSV, resta 10 segundos (solapamiento)
- Se actualiza tras cada ejecución

**3. Backup de versión anterior**
- `MonitoreoLockerTiempoReal_v1_BACKUP.ps1` guardado por si hay problemas

**Primer despliegue exitoso:**
- 39 eventos recuperados en primera ejecución
- Dashboard funciona correctamente

### v2.1 — Deduplicación por clusters (tarde 2026-04-21)

**Problema detectado tras el primer despliegue v2.0:**
- El CSV tenía pares Extracción+Devolución del mismo usuario a 5-15s (artefactos)
- Faltaban consignas que estaban en uso según SQL (solo 8 aparecían en vez de 12)
- Causa raíz: ACTUM emite **dos tipos de eventos por interacción**: tipo `10000` y tipo `10001`

**Descubrimiento clave — Tipos de Evento en SQL:**

| Evento | Total | Significado |
|---|---|---|
| 1 | 12.329 | ? |
| 2 | 11.716 | ? |
| 3 | 140.131 | Puerta cierra |
| 4 | 2.317 | Puerta abre |
| 1002 | 1.451 | ? |
| 3001-3004 | ~385 | ? |
| 3601-3602 | ~48 | ? |
| 4001 | 15 | ? |
| **10000** | **270** | **Identificación usuario (tipo A)** |
| **10001** | **261** | **Identificación usuario (tipo B)** |

**Ambos eventos 10000 y 10001 son identificaciones válidas.** ACTUM emite 1 de cada para la misma acción física (usuario se identifica, abre, cierra). Antes solo leíamos 10000 → perdíamos ~50% de eventos, en especial los de usuarios SAT.

**Solución implementada:**
1. Query actualizada a `Evento IN (10000, 10001)`
2. Deduplicación por clusters:
   - Cluster = eventos consecutivos con mismo Consigna + mismo Usuario + `<= 60s` de separación
   - Regla: cluster → conservar solo 1 evento (el más antiguo)
   - Alternancia desde estado actual de SQL asigna la acción correcta (Extracción/Devolución)

**4. ReconstruirHistorial.ps1 (nuevo script, ejecutar UNA VEZ)**
- Lee TODA la tabla Eventos (10000+10001) desde oct 2024
- Aplica dedup por clusters
- Procesa por consigna desde el estado actual de SQL hacia atrás (alternancia reversed)
- Reescribe `HistorialCompleto.csv` desde cero con 473 movimientos limpios
- Actualiza `UltimoEventoProcesado.txt`
- Útil también en el futuro si se detectan anomalías

**Resultado final del despliegue v2.1 (2026-04-21):**
| Métrica | Antes | Ahora |
|---|---|---|
| Eventos CSV | ~270 (solo 10000) | **473** (10000+10001, deduplicado) |
| Consignas en uso detectadas | 8 | **12** (coincide con SQL) |
| Artefactos duplicados | Abundantes | 58 eliminados automáticamente |
| Pérdida de datos | Si PC apagado | **Cero** |
| Usuarios SAT registrados | No | **Sí** (eventos 10001) |

### v2.1 UX — Dashboard Refresh + Tab persistente

**Mejoras en GenerarDashboard.ps1:**

**1. Refresh sincronizado al `:00`**
- Antes: refresh a 60s desde carga (ej: 11:32:13, 11:33:13...)
- Ahora: refresh al segundo 00 exacto (ej: 11:33:00, 11:34:00...)
- Implementación: script JS inline calcula `(60 - segundos_actuales) * 1000 - ms` y programa `location.reload()`
- Fallback: meta refresh `content="75"` (por si JS bloqueado en OneDrive web)

**2. Pestaña persistente al refresh**
- Antes: cualquier refresh volvía a "Estado Instrumentos" (default)
- Ahora: persiste via hash URL (`#estado` / `#historial`)
- Al cambiar tab → `history.replaceState` actualiza el hash
- Al cargar → lee hash y marca el radio correspondiente

**3. JS ubicado antes de `</body>`** — el script es inline, sin dependencias externas, sin onclick handlers (compatible con OneDrive web)

### Estructura SQL confirmada en esta sesión (2026-04-21)

**Tabla `Eventos`:**
| Campo | Tipo | Descripción |
|---|---|---|
| `Codigo` | uniqueidentifier | GUID |
| `FechaHora` | datetime | Timestamp evento |
| `Evento` | bigint | Tipo (ver tabla arriba) |
| `ElectronicaCU_Codigo` | bigint | |
| `ElectronicaCU_Rele` | bigint | |
| `Consigna_Codigo` | bigint | FK a Consigna |
| `Caja_Codigo` | bigint | FK a Caja |
| `Herramienta_Codigo` | bigint | |
| `Usuario_Codigo` | bigint | FK a Usuario (solo en 10000/10001) |
| `Tratado` | bit | No se usa |

**Tabla `Usuario` — usuarios SAT identificados (`AccesoConsignasRestringidas = True`):**
- 8 IKER L. LASSO · 59 AITOR U. ULIBARRI · 60 JOSE G. G. GONZALEZ GONZALEZ · 62 IÑIGO A. ALONSO · otros

### Reglas permanentes aprendidas

1. **Filtro SQL correcto para identificaciones:** `Evento IN (10000, 10001)`, NO solo `10000`
2. **Dedup por clusters** siempre que se procesen eventos nuevos (umbral `<= 60s`, mismo usuario + misma consigna)
3. **Cluster → conservar 1 evento** (el más antiguo) + alternancia desde SQL
4. **Estado actual SQL = fuente de verdad** para Disponible/En uso
5. **El CSV histórico se puede reconstruir en cualquier momento** con `ReconstruirHistorial.ps1` — útil si se detectan anomalías

### Tema pendiente (sesión futura)

- **Contraseña Windows User del locker** — IT estudia si permitir `PasswordNeverExpires` para que OneDrive no pierda sesión cada 50 días. Prueba inicial con `wmic useraccount` se revirtió (espera decisión IT).

---

## Resumen de Sesion — 2026-03-03

### Problemas encontrados y resueltos:

**1. Dashboard sin actualizar 11 horas**
- Causa raiz: **OneDrive.exe no estaba corriendo** en el locker. Nadie lo habia iniciado tras un reinicio.
- Fix: `Start-Process "C:\Program Files\Microsoft OneDrive\OneDrive.exe"`
- Fix permanente: clave de registro `HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run` con valor `"C:\Program Files\Microsoft OneDrive\OneDrive.exe"`

**2. Tarea GenerarDashboardHTML desactivada (de antes)**
- Fue desactivada manualmente el 24/02/2026
- Fix: `Enable-ScheduledTask -TaskName "GenerarDashboardHTML"` (requiere admin)
- Ahora tiene watchdog: GenerarDashboard.ps1 la reactiva automaticamente si la detecta Disabled

**3. SQL devolvía 0 instrumentos**
- Causa: `JOIN Consigna+Caja WHERE Activa=1` devolvía 0 filas
- Fix: fallback automatico a `SELECT FROM Caja` si el JOIN da 0 resultados

**4. Tildes rotas (caracteres ◆) — CRITICO**
- Causa raiz: `GenerarDashboardHTML` corria como **SYSTEM** (no como User)
- Con SYSTEM, `Integrated Security=True` falla en SQL Express → usa EXPORT_Cajas.txt como fallback
- **EXPORT_Cajas.txt tiene encoding roto** (caracteres como `C□mara Termogr□fica`)
- Fix: cambiar el principal de la tarea a User (Interactive):
  ```powershell
  Set-ScheduledTask -TaskName "GenerarDashboardHTML" -Principal (New-ScheduledTaskPrincipal -UserId "User" -LogonType Interactive -RunLevel Limited)
  ```
- ⚠️ REGLA PERMANENTE: `GenerarDashboardHTML` SIEMPRE debe correr como `User` (Interactive), NUNCA como SYSTEM

**5. Transferencia de scripts via TeamViewer/Notepad — PROBLEMA GRAVE**
- El heredoc `@"..."@` se rompe al pegar scripts largos via clipboard/TeamViewer
- Sintoma: "454 lines" en vez de 688, error "Falta la cadena en el terminador"
- Solucion correcta: enviar el archivo .ps1 directamente (Teams/email), NO copiar-pegar

### Estado del sistema (2026-03-03 09:52):
| Componente | Estado |
|---|---|
| MonitoreoLockerTiempoReal | ✅ User/Interactive, cada 1 min |
| GenerarDashboardHTML | ✅ User/Interactive (cambiado de SYSTEM), cada 1 min |
| ActualizarExcelLocker | ✅ SYSTEM, cada 5 min |
| OneDrive | ✅ Corriendo + auto-arranque configurado en registro |
| Dashboard HTML | ✅ Actualizandose cada minuto, tildes correctas |
| Meta-refresh navegador | ✅ Cada 60 segundos (`<meta http-equiv="refresh" content="60">`) |
| Watchdog tarea | ✅ En GenerarDashboard.ps1 — reactiva GenerarDashboardHTML si Disabled |

### ⚠️ REGLAS CRITICAS para evitar recurrencia:
1. **GenerarDashboardHTML SIEMPRE como User** — NUNCA como SYSTEM (SQL falla)
2. **OneDrive DEBE estar corriendo** — si el PC reinicia y OneDrive no arranca, nada se sincroniza
3. **EXPORT_Cajas.txt tiene encoding roto** — NO es un fallback fiable; mantener SQL funcionando
4. **No pegar scripts largos por Notepad/TeamViewer** — enviar el .ps1 como archivo



**Comportamiento ante reinicio del locker:**
1. PC arranca → entra automáticamente como `User` (auto-login)
2. Al iniciar sesión → Task Scheduler arranca `MonitoreoLockerTiempoReal`
3. Cada 1 minuto → CSV actualizado + HTML generado (oculto, sin ventana)
4. Dashboard disponible en OneDrive en < 1 minuto

**Sistema presentado y aceptado por GHI el 2026-02-25. En producción.**

---

## 🚨 GUÍA RÁPIDA DE ERRORES COMUNES

### Error 1: No sincroniza a OneDrive (la hora no cambia)

**Síntoma:** El HTML local se genera bien pero desde tu PC/web no se actualiza.

**Diagnóstico:**
```powershell
# En el locker:
Get-Item "C:\Users\User\OneDrive...\LockerACTUM\DashboardLocker.html" | Select-Object LastWriteTime
```
Si la hora es reciente → el problema es OneDrive.

**Solución:**
1. Reiniciar OneDrive:
```powershell
Stop-Process -Name OneDrive -Force
Stop-Process -Name "OneDrive.Sync.Service" -Force
Start-Sleep -Seconds 5
Start-Process "C:\Program Files\Microsoft OneDrive\OneDrive.exe"
```
2. Si sigue sin funcionar, la sesión ha expirado → iniciar sesión manualmente en OneDrive desde el navegador.

---

### Error 2: Tarea programada no se ejecuta

**Síntoma:** El HTML no se genera, la hora no cambia.

**Diagnóstico:**
```powershell
Get-ScheduledTaskInfo -TaskName "MonitoreoLockerTiempoReal" | Select-Object LastRunTime, LastTaskResult
```
- LastTaskResult = 0 → OK
- LastTaskResult = otro número → error

**Solución:**
```powershell
# Ver tarea
Get-ScheduledTask -TaskName "MonitoreoLockerTiempoReal" | Select-Object State
# Si está Disabled:
Enable-ScheduledTask -TaskName "MonitoreoLockerTiempoReal"
```

---

### Error 3: Cambio de contraseña del PC

**Síntoma:** OneDrive deja de sincronizar después de cambiar la contraseña del locker.

**Solución:**
1. Iniciar sesión en el locker con la nueva contraseña
2. Arrancar OneDrive si no está corriendo
3. Verificar sincronización

---

###Error 4: HTML con tildes rotos (caracteres raros)

**Síntoma:** En lugar de "Cámara" aparece "C□mara".

**Solución:**
```powershell
# Ejecutar el parche:
powershell -ExecutionPolicy Bypass -File "C:\ACTUM\PatchFuncionTildes.ps1"
```

---

### Checklist rápido de verificación:
```powershell
# 1. Estado tareas
Get-ScheduledTask | Where-Object {$_.TaskName -like "*Locker*" -or $_.TaskName -like "*Dashboard*"} | Select-Object TaskName, State

# 2. Última ejecución
Get-ScheduledTaskInfo -TaskName "MonitoreoLockerTiempoReal" | Select-Object LastRunTime, LastTaskResult

# 3. HTML actualizado
Get-Item "C:\Users\User\OneDrive...\LockerACTUM\DashboardLocker.html" | Select-Object LastWriteTime

# 4. OneDrive corriendo
Get-Process OneDrive -ErrorAction SilentlyContinue
```

**Arquitectura de tareas definitiva (NO cambiar a SYSTEM):**
- `MonitoreoLockerTiempoReal` → **Interactive (User)** — necesita SQL (Integrated Security) y escritura a `C:\Users\User\OneDrive...`
- `GenerarDashboardHTML` → **DISABLED** — redundante, MonitoreoLockerTiempoReal ya genera HTML
- `ActualizarExcel` → puede ser SYSTEM si no usa OneDrive user path

**Fix SQL aplicado (JOIN Consigna+Caja):**
```sql
-- ANTES (bug): clave = Caja.Codigo (no coincidia con Consigna.CodigoCliente del CSV)
SELECT Codigo, CodigoCliente, Descripcion, FechaCaducidad FROM Caja

-- DESPUES (correcto): clave = Consigna.CodigoCliente (mismo que CSV)
SELECT C.CodigoCliente AS ConsignaCod, Cj.CodigoCliente AS CodigoGHI, Cj.Descripcion, Cj.FechaCaducidad
FROM Consigna C JOIN Caja Cj ON C.Caja_Codigo = Cj.Codigo WHERE C.Activa = 1
```

---

## 🚨 REGLA PERMANENTE: Encoding en scripts PowerShell (2026-02-24)

### El problema que ocurrió:
Se escribieron caracteres literales (á, é, ó, ñ...) dentro del código fuente `.ps1`.
Cuando el script se copia al locker (Windows con CP1252 por defecto), esos caracteres UTF-8 se corrompen → el script falla con errores de sintaxis como `Token '&' inesperado`.

### La regla que SIEMPRE hay que seguir:
> **NUNCA usar caracteres especiales (tildes, ñ, etc.) literales en el código fuente PowerShell.**
> Usar SIEMPRE `[char]0xXX` en su lugar.

| Carácter | Usar en PS código |
|---|---|
| á | `[char]0xE1` |
| é | `[char]0xE9` |
| í | `[char]0xED` |
| ó | `[char]0xF3` |
| ú | `[char]0xFA` |
| ñ | `[char]0xF1` |
| ü | `[char]0xFC` |
| Á | `[char]0xC1` |
| É | `[char]0xC9` |
| Í | `[char]0xCD` |
| Ó | `[char]0xD3` |
| Ú | `[char]0xDA` |
| Ñ | `[char]0xD1` |
| Ü | `[char]0xDC` |

### Ejemplo correcto:
```powershell
# MAL: usa literal -> se rompe al copiar
$text = $text -replace 'á', '&aacute;'

# BIEN: usa codigo hex -> funciona en cualquier sistema
$text = $text -replace [char]0xE1, '&aacute;'
```

### Si vuelve a ocurrir el error en el locker:
Usar el script de parche `PatchFuncionTildes.ps1` (en carpeta GHI):
```powershell
# Pegar contenido en PowerShell del locker (via TeamViewer si hace falta)
# O ejecutar desde C:\ACTUM si se ha copiado ahi
powershell -ExecutionPolicy Bypass -File "C:\ACTUM\PatchFuncionTildes.ps1"
```
El parche detecta y reemplaza la función automáticamente, verifica sintaxis y ejecuta el dashboard.

### Dónde se aplica la función actualmente:
- `GenerarDashboard.ps1` → función `ConvertTo-HtmlEntities` al inicio del script
- Se aplica a `Caja.Descripcion` al construir `$estadoInstrumentos`
- Si se añaden nuevos campos de texto desde SQL, aplicar también: `ConvertTo-HtmlEntities $campo`

---

## 🛡️ SOLUCIÓN DEFINITIVA DE ENCODING (2026-02-24) — LA ÚLTIMA LÍNEA DE DEFENSA

### El problema raíz descubierto:
Dos fuentes diferentes generaban dos filas del mismo instrumento con encoding diferente:
- `C&aacute;mara` → ConvertTo-HtmlEntities funcionó correctamente
- `C&#225;mara` → el char Unicode 'á' escapó a ConvertTo-HtmlEntities y lo capturó la red de seguridad

Ambos son idénticos en HTML (`&aacute;` = `&#225;` = 'á'). El navegador los muestra igual.

### La solución: conversión ASCII final antes de escribir el HTML

Al final de `GenerarDashboard.ps1`, en lugar de escribir UTF-8, se convierte el HTML a ASCII puro:

```powershell
# Antes (roto):
$utf8WithBOM = New-Object System.Text.UTF8Encoding $true
[System.IO.File]::WriteAllText($archivoHTML, $html, $utf8WithBOM)

# Ahora (infalible):
$htmlFinal = [System.Text.RegularExpressions.Regex]::Replace($html, '[^\x00-\x7F]', {
    param($match)
    return '&#' + [int][char]$match.Value + ';'
})
$ascii = New-Object System.Text.ASCIIEncoding
[System.IO.File]::WriteAllText($archivoHTML, $htmlFinal, $ascii)
```

### Por qué es infalible:
- Convierte **cualquier carácter > ASCII** (> 127) a entidad numérica `&#NNN;`
- No depende de ConvertTo-HtmlEntities ni del encoding del sistema
- No depende de si SQL conecta o usa fallback CSV
- No depende del account (SYSTEM o interactivo) que ejecuta la tarea
- El fichero resultante es **ASCII puro** — imposible corrupciones de encoding

### Si hay que volver a parchearlo en el locker (TeamViewer):
```powershell
$archivo = "C:\ACTUM\GenerarDashboard.ps1"
$contenido = Get-Content $archivo -Raw -Encoding UTF8
$viejo = '$utf8WithBOM = New-Object System.Text.UTF8Encoding $true
[System.IO.File]::WriteAllText($archivoHTML, $html, $utf8WithBOM)'
$nuevo = @'
$htmlFinal = [System.Text.RegularExpressions.Regex]::Replace($html, '[^\x00-\x7F]', {
    param($match)
    return '&#' + [int][char]$match.Value + ';'
})
$ascii = New-Object System.Text.ASCIIEncoding
[System.IO.File]::WriteAllText($archivoHTML, $htmlFinal, $ascii)
'@
$utf8NoBOM = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($archivo, $contenido.Replace($viejo, $nuevo), $utf8NoBOM)
Write-Host "Parche aplicado" -ForegroundColor Green
& "C:\ACTUM\GenerarDashboard.ps1"
```

### Verificación tras el parche:
```powershell
# Debe mostrar &aacute; o &#225; — NUNCA bytes rotos
Select-String "mara" "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\DashboardLocker.html" |
    Select-Object -First 3 -ExpandProperty Line
```

---

## Resumen de Sesion — 2026-03-25

### Problema: Dashboard sin actualizar desde el 24/03 a las 8h

**Sintoma:** El HTML se generaba correctamente en el locker cada minuto (LastWriteTime actualizado), pero el dashboard no se actualizaba en OneDrive web.

**Causa raiz REAL (confirmada):** La cuenta de OneDrive (`fabricacion1@ghifurnaces.com`) cambio de contrasena. El cliente OneDrive del locker perdio la sesion y dejo de sincronizar archivos al cloud — aunque el proceso OneDrive.exe seguia corriendo, estaba desautenticado.

**Señales que apuntan a este problema:**
- El HTML se actualiza localmente (LastWriteTime reciente en el locker)
- Pero el archivo en OneDrive web muestra version antigua
- OneDrive.exe corre pero con PID desde hace dias (no reciente)
- El icono de OneDrive en la bandeja muestra error de cuenta

**Fix:** Abrir OneDrive en el locker → iniciar sesion con la nueva contrasena → sync se reanuda en segundos.

**Lo que NO era el problema:**
- Tareas programadas: OK
- SQL Server: conexion OK (32 instrumentos)
- Generacion del HTML: OK
- Auto-login: correcto

### Acciones realizadas:

**1. ActualizarExcelLocker estaba Disabled**
- Fix: `Enable-ScheduledTask -TaskName "ActualizarExcelLocker"`

**2. Regeneracion manual del dashboard**
- `cd C:\ACTUM; .\GenerarDashboard.ps1`
- Resultado: SQL OK, 32 instrumentos, 210 movimientos, HTML generado

**3. Fix preventivo — Tareas robustas ante reinicios**
Aplicado `-StartWhenAvailable` y reintentos a las 3 tareas criticas:
```powershell
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -Hidden `
    -StartWhenAvailable `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1)

Set-ScheduledTask -TaskName "MonitoreoLockerTiempoReal" -Settings $settings
Set-ScheduledTask -TaskName "GenerarDashboardHTML" -Settings $settings
Set-ScheduledTask -TaskName "GenerarDashboardAdmin" -Settings $settings
```

**Por que es el fix correcto:** `-StartWhenAvailable` hace que si el PC se reinicia y la tarea "pierde" su ventana horaria, Windows la lanza automaticamente en cuanto el sistema esta listo. Sin esto, la tarea queda en `Ready` pero nunca se dispara hasta el proximo ciclo programado (que puede no llegar si el trigger perdio su referencia).

### Estado del sistema (2026-03-25 08:00):
| Componente | Estado | Notas |
|---|---|---|
| MonitoreoLockerTiempoReal | ✅ Ready | StartWhenAvailable + 3 reintentos |
| GenerarDashboardHTML | ✅ Ready | StartWhenAvailable + 3 reintentos |
| GenerarDashboardAdmin | ✅ Ready | StartWhenAvailable + 3 reintentos |
| ActualizarExcelLocker | ✅ Ready | Reactivada |
| OneDrive | ✅ Corriendo | Desde 21/03 |
| SQL | ✅ OK | 32 instrumentos |
| Dashboard HTML | ✅ Actualizandose cada minuto | Confirmado 7:56:10 |

### Diagnostico rapido (para futuras incidencias):
```powershell
# 1. Estado de tareas
Get-ScheduledTask -TaskName "MonitoreoLockerTiempoReal","GenerarDashboardHTML","ActualizarExcelLocker","GenerarDashboardAdmin" | Select-Object TaskName, State

# 2. Ultima ejecucion y resultado
Get-ScheduledTaskInfo -TaskName "MonitoreoLockerTiempoReal" | Select-Object LastRunTime, LastTaskResult, NextRunTime
Get-ScheduledTaskInfo -TaskName "GenerarDashboardHTML" | Select-Object LastRunTime, LastTaskResult, NextRunTime

# 3. OneDrive corriendo?
Get-Process -Name "OneDrive" -ErrorAction SilentlyContinue | Select-Object Name, StartTime

# 4. Cuando se actualizo el HTML por ultima vez?
Get-Item "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\DashboardLocker.html" | Select-Object LastWriteTime

# 5. Fix rapido si todo esta parado:
Enable-ScheduledTask -TaskName "ActualizarExcelLocker"
cd C:\ACTUM; .\GenerarDashboard.ps1

# 6. CRITICO: Verificar si OneDrive esta sincronizando
# Si el HTML se actualiza localmente pero NO en OneDrive web:
# → Probable cambio de contrasena de la cuenta OneDrive
# → Solucion: abrir OneDrive en el locker e iniciar sesion de nuevo
# → O restart del PC (arranca OneDrive limpio y pide credenciales)
```

## ⚠️ CAUSA FRECUENTE DE FALLO: Cambio de contraseña OneDrive

Si el dashboard deja de actualizarse en OneDrive web pero el archivo local SÍ está actualizado (LastWriteTime reciente):

**Diagnóstico confirmado:** archivos en OneDrive web muestran fecha antigua ("el martes a las 2:00") mientras el HTML local se genera cada minuto.

**Fix — dos pasos:**
1. Click en el icono OneDrive (bandeja sistema) → si pide credenciales, introducirlas
2. **Si el icono muestra "azul girando" pero sigue sin sincronizar:** ir a **OneDrive → Configuración (engranaje) → pestaña Cuenta → re-introducir credenciales** explicitamente ahí
3. En 1-2 minutos el sync se reanuda

> ⚠️ El icono "azul girando" NO garantiza que la cuenta corporativa esté autenticada. OneDrive puede girar por otros motivos mientras la cuenta `fabricacion1@ghifurnaces.com` está desconectada. Verificar siempre en la pestaña Cuenta de Configuración.

> ⚠️ Cada vez que se cambie la contraseña de `fabricacion1@ghifurnaces.com` (o la cuenta OneDrive del locker), hay que volver a autenticar OneDrive en el PC del locker.

### ⚠️ Estado "Buscando cambios..." atascado tras re-autenticacion

**Sintoma:** Tras introducir la nueva contrasena en OneDrive, el icono queda en "Buscando cambios..." durante mas de 10 minutos y no sube nada al cloud. El explorador de archivos muestra los archivos actualizados localmente pero OneDrive web sigue mostrando la version antigua.

**Causa:** OneDrive se queda colgado en el proceso de reconexion tras el cambio de credenciales.

**Fix — SIN necesidad de PowerShell ni IA:**
1. Conectarse al locker (TeamViewer o en persona)
2. Click derecho en el icono de OneDrive en la bandeja del sistema (esquina inferior derecha)
3. **Cerrar OneDrive**
4. Buscar "OneDrive" en el menu inicio y ejecutarlo
5. Esperar 2 minutos → el dashboard web se actualiza solo

### Contrasena de `fabricacion1` — quien se encarga

> **ACTUALIZADO 2026-09-08: no hay respaldo. Imanolia lo hace sola.**
> El companero que cubria el locker durante el verano de 2026 ya no esta. No hay segunda persona con
> TeamViewer ni punto de contacto alternativo. Toda intervencion en el locker la hace ella directamente.
> **Consecuencia operativa:** si nadie mira, nadie se entera — es el mismo agujero que dejo el PC 19 dias
> muerto en agosto. Refuerza el argumento de la alerta de sistema caido (pendiente 8).

- Contrasena cambiada el **10/06/2026**, con OneDrive re-autenticado ese mismo dia (tokens frescos)
- Caducidades siguientes: ~22/07/2026 y ~26/08/2026 — **la de agosto no consta re-autenticada**
- **Accion cuando caduca:** entrar al locker, meter la contrasena nueva en OneDrive
  (icono → Configuracion → pestana **Cuenta**), y cerrar/reabrir OneDrive si se queda en "Buscando cambios..."
- **Comportamiento de tokens OAuth:** cambiar la contrasena NO rompe OneDrive inmediatamente — el cliente
  sigue funcionando hasta que el refresh token caduca (dias/semanas). Por eso conviene re-autenticar cuanto
  antes tras el cambio, para tener tokens frescos.

---

## Resumen de Sesion — 2026-04-30 (Bug marcador formato fecha)

### Problema: Sin movimientos registrados desde el 17/04/2026

**Sintoma:** El CSV terminaba el 17/04/2026 07:48:14 (ALVARO T. TREPIANA). La tarea corria cada minuto (LastTaskResult=0) pero no registraba nada. `UltimoEventoProcesado.txt` no existia en `C:\ACTUM\` (buscamos en la ruta incorrecta).

**Causa raiz — Bug de formato en `MonitoreoLockerTiempoReal.ps1`:**
- Cuando el script procesaba movimientos nuevos, guardaba el marcador en formato `MM/dd/yyyy HH:mm:ss` (formato del CSV, ej: `04/17/2026 07:48:14`)
- En la siguiente ejecucion, intentaba leerlo como `yyyy-MM-dd HH:mm:ss` → fallo de parseo
- Caia al fallback: leia el CSV, calculaba el marcador desde la ultima linea (07:48:04), buscaba en SQL → el dedup cross-batch eliminaba ese evento (ya estaba en el CSV) → 0 movimientos nuevos
- Sobreescribia el marcador con `(Get-Date)` → desde ese momento el marcador era "ahora"
- En adelante: siempre buscaba desde "ahora", nunca encontraba eventos pasados

**Nota:** El marcador real esta en `C:\Users\User\OneDrive...\LockerACTUM\UltimoEventoProcesado.txt`, NO en `C:\ACTUM\`. Error de diagnostico inicial al buscar en la ruta equivocada.

**Fix aplicado en `MonitoreoLockerTiempoReal.ps1` (linea 385-387):**
```powershell
# ANTES (bug): guardaba en formato MM/dd/yyyy HH:mm:ss
$ultimoTimestamp = ($nuevosMovimientos | Sort-Object FechaHoraApertura | Select-Object -Last 1).FechaHoraApertura
[System.IO.File]::WriteAllText($archivoMarcador, $ultimoTimestamp, $utf8NoBOM)

# DESPUES (correcto): siempre formato yyyy-MM-dd HH:mm:ss
$ultimaFechaObj = [DateTime]::ParseExact(
    ($nuevosMovimientos | Sort-Object FechaHoraApertura | Select-Object -Last 1).FechaHoraApertura,
    'MM/dd/yyyy HH:mm:ss', $null)
[System.IO.File]::WriteAllText($archivoMarcador, $ultimaFechaObj.ToString('yyyy-MM-dd HH:mm:ss'), $utf8NoBOM)
```

**Recuperacion de eventos perdidos:**
- Se ejecuto `ReconstruirHistorial.ps1` con la tarea pausada (`Disable-ScheduledTask`)
- Resultado: 537 eventos SQL → 58 artefactos eliminados → 479 movimientos limpios (antes 473)
- Marcador actualizado a `2026-04-30 09:45:23` en formato correcto
- 12 consignas "En uso" recuperadas correctamente

**Fix cosmético adicional en `GenerarDashboard.ps1`:**
- El historial solo mostraba `Usuario` (ej: "ALVARO T.") sin apellidos
- Fix: `$(("$($movimiento.Usuario) $($movimiento.Apellidos)").Trim())` → ahora muestra nombre completo (ej: "ALVARO T. TREPIANA")

### Regla permanente aprendida:
> **El marcador `UltimoEventoProcesado.txt` SIEMPRE debe estar en formato `yyyy-MM-dd HH:mm:ss`.**
> Esta en `C:\Users\User\OneDrive...\LockerACTUM\`, NO en `C:\ACTUM\`.
> Si el sistema deja de registrar movimientos y la tarea corre sin errores (LastTaskResult=0), comprobar el contenido y formato de ese archivo primero.

---

## Resumen de Sesion — 2026-05-14 (OneDrive sin sesion, sin perdida de datos)

### Problema: Dashboard sin actualizar desde ~06/05/2026

**Sintoma:** El dashboard no se actualizaba en OneDrive web. El HTML local SI se generaba (LastWriteTime 14/05/2026 09:02:16).

**Causa raiz:** La cuenta OneDrive (`fabricacion1@ghifurnaces.com`) cambio de contrasena (~6 mayo). El proceso OneDrive.exe seguia corriendo (desde 09/05/2026 19:10:18) pero sin sesion autenticada → no sincronizaba nada.

**Fix (paso 1):** Click en el icono de OneDrive en la bandeja del sistema → introducir nueva contraseña si aparece aviso.

**Fix (paso 2 — si el paso 1 no basta):** OneDrive puede seguir sin sincronizar aunque el proceso corra y el icono muestre "azul girando". En ese caso hay que ir a **OneDrive → Configuración (engranaje) → pestaña Cuenta → re-introducir credenciales** explicitamente. Esto fue necesario en la segunda incidencia del 14/05.

**Verificacion de datos:**
- CSV terminaba en 05/06/2026 11:25:52 (ANGEL F. FERNANDEZ, consigna 13)
- SQL: 0 eventos desde el 6/05 → nadie uso el locker en esos 8 dias
- Marcador `UltimoEventoProcesado.txt`: `2026-05-14 09:11:06` (formato correcto)
- **Sin perdida de datos** — las tareas programadas funcionaron correctamente durante toda la interrupcion

**Lo que NO era el problema:**
- Tareas programadas: OK (LastTaskResult=0, HTML generado cada minuto)
- SQL Server: OK (0 eventos nuevos, pero conexion activa)
- Marcador: formato correcto

### Nota diagnostica — Sort-Object con fechas MM/dd/yyyy

`Sort-Object FechaHoraApertura` sobre el CSV ordena **alfabeticamente**, no cronologicamente. "12/..." (diciembre) aparece despues de "05/..." (mayo), lo que puede confundir el diagnostico.

**Para ver los ultimos movimientos reales usar:**
```powershell
# Opcion 1: tail del CSV (escrito en orden cronologico)
Get-Content "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\HistorialCompleto.csv" | Select-Object -Last 20

# Opcion 2: filtrar por ano
Import-Csv "...\HistorialCompleto.csv" -Delimiter ";" |
    Where-Object { $_.FechaHoraApertura -like "*2026*" } |
    Select-Object -Last 15 | Format-Table -AutoSize
```

### Estado del sistema (2026-05-14):
| Componente | Estado | Notas |
|---|---|---|
| MonitoreoLockerTiempoReal | ✅ Corriendo | Sin interrupcion durante el fallo de OneDrive |
| OneDrive | ✅ Autenticado | Re-autenticado manualmente 14/05 |
| CSV HistorialCompleto | ✅ Completo | Sin perdida de datos (locker no usado 06-14/05) |
| Marcador UltimoEventoProcesado | ✅ Correcto | `2026-05-14 09:11:06` formato yyyy-MM-dd |

---

## Resumen de Sesion — 2026-05-20 (Investigacion alternativas a OneDrive)

### Contexto

IT confirma que la politica de cambio de contrasena de `fabricacion1@ghifurnaces.com` cada ~50 dias **no se puede modificar**. Se investigo si existe alguna alternativa al cliente OneDrive para sincronizar el dashboard.

### Analisis de red del locker (GHI-TAQUILLAS)

| Parametro | Valor |
|---|---|
| IP | 172.16.5.40 |
| Mascara | 255.255.255.0 |
| Gateway | 172.16.5.1 |
| DNS | 8.8.8.8 / 8.8.4.4 (Google — NO corporativo) |
| Acceso internet | ✅ SI (ping 8.8.8.8 OK, 7ms) |
| Acceso servidor documental | ❌ NO |

**Por que no llega al servidor documental:**
- `\\srvdocumental\Ghihornos` → IP real: `192.168.210.250`
- El locker esta en subred `172.16.5.x`, el servidor en `192.168.210.x` — subredes distintas sin routing entre ellas
- El DNS del locker es Google (8.8.8.8), no el DNS corporativo → no resuelve nombres `.ghihornos.local`

### Alternativas investigadas

**1. Carpeta de red compartida (`\\srvdocumental\Ghihornos`)** — ❌ DESCARTADA
- No accesible desde el locker (subredes distintas)

**2. Azure Blob Storage** — ⏳ PENDIENTE (futura)
- Viable tecnicamente: locker tiene internet, script usa `Invoke-RestMethod` (sin modulos extra)
- SAS token con expiracion en 2030 — sin dependencia de contrasenas de usuario
- URL permanente y publica
- **Descartada por ahora:** GHI no tiene suscripcion Azure disponible
- **Retomar cuando tengan Azure**

**3. Microsoft Graph API con App Registration** — ⏳ PENDIENTE (futura)
- Parte de M365 que GHI ya tiene (Azure AD / Microsoft Entra ID) — sin coste adicional
- IT registra la app una vez (10 min). Autenticacion por certificado: **no caduca nunca**
- Script sube HTML a SharePoint/OneDrive con ese certificado en vez de con fabricacion1
- URL para usuarios queda exactamente igual
- **Pendiente de evaluar con IT**

**4. Servidor web en el propio locker (IIS)** — ⏳ PENDIENTE (futura)
- Script deja HTML en `C:\inetpub\wwwroot\`, gente accede por `http://172.16.5.40/DashboardLocker.html`
- Cero sincronizacion, cero cuentas que caduquen
- **Bloqueante:** no se sabe si los PCs de oficina (192.168.x.x) pueden llegar a 172.16.5.40
- **Pendiente de verificar conectividad**

### Decision

Se mantiene el sistema actual con OneDrive + fabricacion1. Cuando la contrasena caduca → re-autenticar manualmente en el locker (icono OneDrive → Configuracion → Cuenta).

Las alternativas 2, 3 y 4 quedan documentadas para retomar en el futuro.

---

## Limitacion conocida: Asignaciones administrativas en ACTUM

**Descubierto 2026-05-20** al verificar consigna 30.

`Consigna.Usuario_Codigo` en SQL puede no coincidir con el ultimo movimiento fisico registrado en la tabla `Eventos`. Esto ocurre cuando alguien asigna un usuario a una consigna directamente desde el software ACTUM EPI Visor (sin que el usuario abra el locker fisicamente). Ese tipo de asignacion NO genera entrada en `Eventos`.

**Consecuencia:** El dashboard puede mostrar un usuario diferente al que ACTUM tiene asignado.
**Impacto:** Solo afecta a quien se muestra como "En uso por X". El instrumento si aparece como EN USO. No es un bug, es una limitacion estructural.
**Solucion futura:** Leer `Consigna.Usuario_Codigo` directamente en `GenerarDashboard.ps1` para la pestana Estado, en vez de derivarlo del CSV.

---

---

## Resumen de Sesion — 2026-05-20 (Bug marcador + Reconstruccion semanal automatica)

### Problema: Movimiento no registrado en dashboard

**Sintoma:** Un movimiento real (JOSE G. G. GONZALEZ devolvio consigna 03 a las 12:42:29) aparecia en la tabla SQL `Eventos` pero no en el CSV ni en el dashboard.

**Causa raiz — Bug del marcador en `MonitoreoLockerTiempoReal.ps1`:**
```powershell
# ANTES (bug): cuando no habia eventos, se actualizaba a Get-Date
} else {
    [System.IO.File]::WriteAllText($archivoMarcador, (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $utf8NoBOM)
}
```
El marcador avanzaba cada minuto aunque no hubiera actividad. Cuando llego el evento a las 12:42:29, el marcador ya habia pasado esa hora → el evento quedo "en el pasado" y nunca fue procesado.

**Fix aplicado en `MonitoreoLockerTiempoReal.ps1`:**
- Si no hay eventos en SQL (`$eventosEnSQL = 0`): NO actualizar el marcador — se mantiene en el ultimo evento real
- Si SQL encontro eventos pero el dedup los elimino todos (`$eventosEnSQL > 0` pero `$nuevosMovimientos = 0`): avanzar marcador al ultimo evento SQL para no reprocesarlos siempre

**Bug secundario sin diagnosticar (1a ocurrencia):**
Durante la recuperacion (marcador reseteado a 12:42:00), el script encontro 1 evento pero produjo 0 movimientos — sin mensaje de error ni de dedup. Causa exacta desconocida. Ocurrio en 2 de 487 eventos totales (0.4%). No critico pero real.

> **✅ RESUELTO 2026-06-02:** Se añadio un SAFETY NET en `MonitoreoLockerTiempoReal.ps1` (ver sesion 2026-06-02).

**Recuperacion de datos:**
1. Evento manual añadido al CSV via PowerShell
2. `ReconstruirHistorial.ps1` ejecutado → 487 movimientos limpios (2 mas que antes)
3. Marcador actualizado a `2026-05-20 12:42:29` (formato correcto)

### Tarea programada semanal: `ReconstruirCSVSemanal`

Creada como seguro definitivo contra cualquier evento perdido:
- **Cuando:** Cada lunes a las 05:00 AM
- **Que hace:** Para MonitoreoLocker (75s) → ReconstruirHistorial → GenerarDashboard → reactiva MonitoreoLocker
- **Archivos:**
  - `C:\ACTUM\ReconstruirSemanal.ps1` — script principal
  - `C:\ACTUM\EjecutarReconstruccionOculto.vbs` — wrapper invisible

**Resultado:** Cualquier movimiento perdido durante la semana queda recuperado automaticamente el lunes. Sin intervencion manual.

### Estado de tareas programadas (2026-05-20):
| Tarea | Frecuencia | Estado |
|---|---|---|
| `MonitoreoLockerTiempoReal` | Cada 1 min | ✅ Ready |
| `GenerarDashboardHTML` | Cada 1 min | ✅ Ready |
| `GenerarDashboardAdmin` | Cada 1 min | ✅ Ready |
| `ActualizarExcelLocker` | Cada 5 min | ✅ Ready |
| `ReconstruirCSVSemanal` | **Lunes 05:00** | ✅ Ready (NextRun: 25/05/2026) |

### Regla permanente: here-strings en PowerShell via TeamViewer/chat

Al pegar comandos con here-string (`@'...'@`) desde el chat, la indentacion hace que `'@` no quede en columna 0 → PowerShell entra en modo de continuacion y el bloque no se ejecuta nunca.

**Solucion:** Usar arrays en lugar de here-strings para crear contenido de archivos:
```powershell
# MAL: here-string (se rompe al pegar con indentacion)
$content = @'
linea1
linea2
'@

# BIEN: array join (funciona siempre)
$lines = 'linea1', 'linea2'
$content = $lines -join "`r`n"
```

---

## Resumen de Sesion — 2026-05-21 (Dedup 60s → 10s + Fix manual consigna 13)

### Problema: Extraccion no registrada en consigna 13

**Sintoma:** Consigna 13 (Analizador particulas / KLOTZ / AMF20707) mostraba "Disponible" en el dashboard pero el instrumento estaba fisicamente extraido por ANGEL F. FERNANDEZ.

**Secuencia real confirmada:**

| Hora | Accion | En CSV |
|---|---|---|
| 10:54:12 | ANGEL F. FERNANDEZ Extraccion | OK |
| 11:19:54 | ANGEL F. FERNANDEZ Devolucion | OK |
| 11:20:10 | ANGEL F. FERNANDEZ Extraccion | NO — perdida |

**Diagnostico:**
- SQL `Eventos`: ultimo evento consigna 13 = `05/21/2026 11:20:10`, Evento=10000, Usuario=26 (ANGEL F.)
- Gap entre ultimo CSV (11:19:54) y evento SQL (11:20:10) = **16 segundos**
- Con `$ventanaSeg = 60`: 16 < 60 → el dedup cross-batch descartaba el evento como duplicado

**Causa raiz — ventana dedup demasiado amplia:**
El dedup cross-batch agrupa como "artefacto" cualquier evento del mismo usuario + consigna dentro de `$ventanaSeg` segundos del ultimo evento en CSV. Un gap de 16 segundos era suficiente para descartarlo con ventana de 60s.

**Fix aplicado — `MonitoreoLockerTiempoReal.ps1` linea 130:**
```powershell
# ANTES:
$ventanaSeg = 60

# AHORA:
$ventanaSeg = 10
```

Con 10 segundos: los duplicados reales de ACTUM (pares 10000+10001, tipicamente < 2s) siguen eliminandose. Acciones reales con > 10s de separacion ya no se descartan. Fisicamente imposible abrir, sacar/devolver y cerrar un locker en menos de 10 segundos.

**Bug secundario confirmado (2a ocurrencia — igual que 2026-05-20):**
Con marcador reseteado a 11:20:09 y ventanaSeg=10, el evento de 11:20:10 paso el filtro dedup (sin mensaje [DEDUP]) pero `$nuevosMovimientos` quedo = 0 sin explicacion ni mensaje de error. Misma conducta que el bug documentado el 20/05. Causa exacta desconocida. Ocurrencia estimada < 1% de eventos.

> **✅ RESUELTO 2026-06-02:** Se añadio un SAFETY NET en `MonitoreoLockerTiempoReal.ps1` (ver sesion 2026-06-02).

**Fix manual del CSV (ejecutado en el locker):**
```powershell
$utf8NoBOM = New-Object System.Text.UTF8Encoding $false
$linea = "05/21/2026 11:20:10;ANGEL F.;FERNANDEZ;13;Analizador part$([char]237)culas / KLOTZ / AMF20707;Extracci$([char]243)n;Cerrada"
[System.IO.File]::AppendAllText("C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\HistorialCompleto.csv", "$linea`r`n", $utf8NoBOM)
[System.IO.File]::WriteAllText("C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\UltimoEventoProcesado.txt", "2026-05-21 11:20:10", $utf8NoBOM)
```

**Resultado:** Dashboard regenerado con 494 movimientos. Consigna 13 muestra "En uso por ANGEL F. FERNANDEZ".

**Nota:** El `ReconstruirCSVSemanal` del lunes 25/05/2026 a las 05:00 recuperara automaticamente cualquier evento perdido esta semana.

---

## Resumen de Sesion — 2026-06-04 tarde (Bug raiz resuelto: Group-Object → hashtable)

### Bug raiz de todos los eventos perdidos — RESUELTO DEFINITIVAMENTE

**Causa raiz confirmada:** `Group-Object { "$($_['Consigna_Codigo'])" }` en PASO 4 fallaba silenciosamente cuando los elementos eran `DataRow` almacenados en `List[object]`. PowerShell no puede resolver el indexer de DataRow a traves del pipeline cuando el tipo declarado es `object`. Resultado: `$porConsigna` quedaba vacio, el foreach no ejecutaba, `$nuevosMovimientos` = 0 sin ningun error visible.

El SAFETY NET no lo capturaba porque `$nuevosMovimientos` quedaba en un estado ambiguo (no exactamente 0 ni >0 en algunos casos).

**Fix aplicado en `MonitoreoLockerTiempoReal.ps1` (PASO 4):**
```powershell
# ANTES (bug):
$porConsigna = $filasLimpias | Group-Object { "$($_['Consigna_Codigo'])" }

# AHORA (correcto):
$porConsigna = @{}
foreach ($fila in $filasLimpias) {
    $k = "$([int][string]$fila['Consigna_Codigo'])"
    if (-not $porConsigna.ContainsKey($k)) { $porConsigna[$k] = [System.Collections.Generic.List[object]]::new() }
    $porConsigna[$k].Add($fila)
}
```

Mismo patron `[string]$fila['Columna']` que ya funcionaba en el SAFETY NET.

**Fix adicional:** `@()` en Sort-Object final para garantizar siempre un array:
```powershell
$nuevosMovimientos = @($nuevosMovimientos | Sort-Object { ... })
```

**Verificacion:** Devolicion consigna 28 (AITOR U. ULIBARRI, 08:17:04) registrada automaticamente tras el deploy. 516 movimientos.

### Estado del sistema (2026-06-04 tarde):
| Componente | Estado | Notas |
|---|---|---|
| MonitoreoLockerTiempoReal | ✅ v2.3 | Bug raiz PASO 4 resuelto, hashtable en lugar de Group-Object |
| CSV HistorialCompleto | ✅ 516 movimientos | |
| Tareas programadas | ✅ 5 activas (Ready) | |

---

## Resumen de Sesion — 2026-06-10 (Correccion manual usuario consignas 18 y 22)

### Problema: Consignas 18 y 22 mostraban "En uso por IKER L. LASSO" en vez de SERGIO V. VEGA

**Causa:** El ultimo movimiento registrado en el CSV para ambas consignas era una Extraccion de IKER L. LASSO (16/04/2026). En realidad quien las tenia era SERGIO V. VEGA (asignacion no registrada en Eventos SQL).

**Verificacion previa:**
- SERGIO V. VEGA confirmado en tabla Usuario: `Codigo=14, CodigoCliente=0014, Nombre=SERGIO V., Apellidos=VEGA`
- Ultimas entradas CSV consigna 18: Extraccion IKER L. LASSO 04/16/2026 11:52:41
- Ultimas entradas CSV consigna 22: Extraccion IKER L. LASSO 04/16/2026 12:44:02

**Fix aplicado — 4 lineas manuales anadidas al CSV:**
```powershell
$utf8NoBOM = New-Object System.Text.UTF8Encoding $false
$csv = "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\HistorialCompleto.csv"
$lineas = @(
    "04/16/2026 11:53:00;IKER L.;LASSO;18;MedidorLaserpuntoderocio / DP510 / 45174428;Devoluci$([char]0xF3)n;Cerrada",
    "04/16/2026 11:53:30;SERGIO V.;VEGA;18;MedidorLaserpuntoderocio / DP510 / 45174428;Extracci$([char]0xF3)n;Cerrada",
    "04/16/2026 12:44:30;IKER L.;LASSO;22;An.gases / TESTO 340 / 63862113;Devoluci$([char]0xF3)n;Cerrada",
    "04/16/2026 12:45:00;SERGIO V.;VEGA;22;An.gases / TESTO 340 / 63862113;Extracci$([char]0xF3)n;Cerrada"
)
foreach ($linea in $lineas) { [System.IO.File]::AppendAllText($csv, "$linea`r`n", $utf8NoBOM) }
cd C:\ACTUM; .\GenerarDashboard.ps1
```

**Resultado:** 526 movimientos. Dashboard muestra "En uso por SERGIO V. VEGA" en consignas 18 y 22.

### Patron para correccion manual de usuario en una consigna

Cuando el dashboard muestra un usuario incorrecto (asignacion administrativa en ACTUM sin apertura fisica):
1. Verificar el nombre exacto en SQL: `SELECT Nombre, Apellidos FROM Usuario WHERE Nombre LIKE '%X%'`
2. Ver ultima entrada del CSV para esa consigna: `Import-Csv ... | Where-Object { $_.Consigna -eq 'N' } | Select-Object -Last 3`
3. Anadir Devolucion del usuario incorrecto + Extraccion del usuario correcto con timestamps justo despues
4. Ejecutar `.\GenerarDashboard.ps1`

### Estado del sistema (2026-06-10):
| Componente | Estado | Notas |
|---|---|---|
| MonitoreoLockerTiempoReal | ✅ v2.3 | Sin cambios |
| CSV HistorialCompleto | ✅ 526 movimientos | +4 correcciones manuales consignas 18 y 22 |
| Tareas programadas | ✅ 5 activas (Ready) | Sin cambios |

---

## Resumen de Sesion — 2026-06-11 (Quitar auto-refresh dashboard)

### Problema: el dashboard volvía al tab "Estado Instrumentos" cada minuto

**Causa:** `GenerarDashboard.ps1` incluía dos mecanismos de auto-refresh:
- `<meta http-equiv="refresh" content="75">` — recarga completa cada 75s (fallback)
- `setTimeout(function(){ location.reload(); }, ms)` — JS que recargaba al :00 exacto

OneDrive web bloquea JS → solo actuaba el meta refresh → recarga completa → tab siempre volvía al default (Estado Instrumentos). El usuario perdía el tab donde estaba cada minuto.

**Fix aplicado en `GenerarDashboard.ps1`:**
- Eliminado el `<meta http-equiv="refresh">` 
- Eliminado el `setTimeout location.reload()` del bloque JS
- Conservado el JS de persistencia de tab via hash URL (inofensivo)

### Fix adicional: formato de fecha dd/MM/yyyy (europeo)

Las fechas en el historial mostraban formato americano `MM/dd/yyyy` (ej: `06/10/2026`) en vez del europeo `dd/MM/yyyy` (ej: `10/06/2026`).

**Causa:** el CSV almacena fechas en formato `MM/dd/yyyy HH:mm:ss` (formato del locker) y se mostraban directamente sin convertir.

**Fix en linea 654 de `GenerarDashboard.ps1`** — solo afecta a la presentacion, el CSV no cambia:
```powershell
# ANTES:
$($movimiento.FechaHoraApertura)

# AHORA:
$(try { [DateTime]::ParseExact($movimiento.FechaHoraApertura,'MM/dd/yyyy HH:mm:ss',$null).ToString('dd/MM/yyyy HH:mm:ss') } catch { $movimiento.FechaHoraApertura })
```
El `catch` garantiza que si alguna fecha tiene formato inesperado, se muestra tal cual sin romper nada.

**Por que no rompe nada:** el dashboard se actualiza porque la tarea programada reescribe el archivo HTML cada minuto. El navegador no necesita auto-recargarse — cuando el usuario abre el dashboard ya ve la version mas reciente. Si quiere actualizar pulsa F5.

**Verificacion:**
```powershell
Select-String -Pattern "refresh|reload" "C:\ACTUM\GenerarDashboard.ps1"
# Solo debe aparecer el comentario: "sin auto-reload" — ningun codigo funcional
```

### Estado del sistema (2026-06-11 — ESTADO FINAL ANTES DE VACACIONES):
| Componente | Estado | Notas |
|---|---|---|
| MonitoreoLockerTiempoReal | ✅ v2.3 | Bug raiz resuelto, sin cambios |
| GenerarDashboard | ✅ Sin auto-refresh, fechas dd/MM/yyyy | Tabs quietos, formato europeo |
| CSV HistorialCompleto | ✅ 528 movimientos | |
| Tareas programadas | ✅ 5 activas (Ready) | |
| OneDrive | ✅ Autenticado | Tokens frescos desde 10/06/2026 |
| Proxima accion manual | ⏳ | Re-autenticar OneDrive al caducar la contrasena (lo hace Imanolia) |

### Inventario de archivos en el locker (2026-06-04)

**C:\ACTUM — archivos activos:**
| Archivo | Fecha | Rol |
|---|---|---|
| `MonitoreoLockerTiempoReal.ps1` | 04/06/2026 | ✅ Script principal (v2.3) |
| `GenerarDashboard.ps1` | 21/04/2026 | ✅ Genera DashboardLocker.html |
| `GenerarDashboardAdmin.ps1` | 10/03/2026 | ✅ Genera DashboardAdmin.html |
| `ReconstruirHistorial.ps1` | 21/04/2026 | ✅ Reconstruccion manual/semanal |
| `ReconstruirSemanal.ps1` | 20/05/2026 | ✅ Wrapper reconstruccion semanal |
| `ActualizarExcel.ps1` | 19/02/2026 | ✅ Actualiza Excel instrumentos |
| `EjecutarMonitoreoOculto.vbs` | 12/02/2026 | ✅ Wrapper VBS MonitoreoLocker |
| `EjecutarDashboardOculto.vbs` | 19/02/2026 | ✅ Wrapper VBS Dashboard |
| `EjecutarAdminOculto.vbs` | 26/02/2026 | ✅ Wrapper VBS DashboardAdmin |
| `EjecutarExcelOculto.vbs` | 19/02/2026 | ✅ Wrapper VBS Excel |
| `EjecutarReconstruccionOculto.vbs` | 20/05/2026 | ✅ Wrapper VBS Reconstruccion |

**Archivos inofensivos — NO tocar:**
- `UltimoEventoProcesado.txt` en C:\ACTUM — leftover de abril, el real esta en OneDrive
- `Monitoreo Locker Tiempo Real` (tarea Disabled con espacios) — tarea duplicada obsoleta
- `EXPORT_*.txt` — desactualizados (feb 2026), fallback SQL
- Backups .ps1 — historicos

---

## Resumen de Sesion — 2026-06-04 (Timeout ACTUM + tiempo tareas + fixes movimientos perdidos)

### Cambios aplicados

**1. Timeout puerta ACTUM: 20s → 60s**
- Configurado en ACTUM EPI Visor → Parámetros → "Segundos Timeout Puerta"
- Causa raiz de operaciones incompletas: el locker cortaba la sesion antes de que el usuario terminara
- Con 60s hay margen suficiente para abrir, sacar/devolver y cerrar

**2. ExecutionTimeLimit tareas: 5 min → 15 min**
- Afectaba a: `MonitoreoLockerTiempoReal`, `GenerarDashboardAdmin`, `ActualizarExcelLocker`
- Comando usado (como admin):
  ```powershell
  $ts = New-TimeSpan -Minutes 1
  $te = New-TimeSpan -Minutes 15
  $s = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden -StartWhenAvailable -ExecutionTimeLimit $te -RestartCount 3 -RestartInterval $ts
  Set-ScheduledTask -TaskName "MonitoreoLockerTiempoReal" -Settings $s
  Set-ScheduledTask -TaskName "GenerarDashboardAdmin" -Settings $s
  Set-ScheduledTask -TaskName "ActualizarExcelLocker" -Settings $s
  ```
- Verificacion: `(Get-ScheduledTask -TaskName "MonitoreoLockerTiempoReal").Settings.ExecutionTimeLimit` → `PT15M`

**3. Fix movimientos manuales (consignas 25 y 30)**
- Consigna 30 JAVIER L. LOZA Devolucion 06/02/2026 14:00:10
- Consigna 25 INIGO A. ALONSO Devolucion 06/03/2026 10:01:52
- 506 movimientos totales en CSV

### Estado del sistema (2026-06-04):
| Componente | Estado | Notas |
|---|---|---|
| MonitoreoLockerTiempoReal | ✅ v2.2 | ventanaSeg=3, marcador conservador, SAFETY NET mejorado |
| Timeout puerta ACTUM | ✅ 60s | Subido desde 20s en ACTUM EPI Visor |
| ExecutionTimeLimit tareas | ✅ PT15M | Subido desde PT5M |
| CSV HistorialCompleto | ✅ 506 movimientos | |

---

## Resumen de Sesion — 2026-06-02 tarde (4a ocurrencia + fix definitivo ventanaSeg + marcador)

### Problema: Devolucion de consigna 30 no registrada

**Sintoma:** JAVIER L. LOZA devolvio consigna 30 (Medidor LCR / RS Pro LCR1701 / ESCFJ000970) a las 14:00:10. No aparecia en CSV ni en dashboard. Marcador = `2026-06-02 14:00:10` exactamente.

**Causa raiz — marcador == timestamp del evento:**
La query usa `FechaHora > @ultimo` (estrictamente mayor). El marcador estaba en `14:00:10` que es IGUAL al evento → la query devuelve 0 filas. Evento excluido permanentemente.

El marcador llego a `14:00:10` porque en la ejecucion anterior: SQL encontro el evento (`$eventosEnSQL=1`), pero `$nuevosMovimientos.Count=0` (PASO 4 bug o dedup). El bloque else avanzaba el marcador al ultimo evento SQL deduplicado → exactamente `14:00:10`.

**Fix manual:**
```powershell
$utf8NoBOM = New-Object System.Text.UTF8Encoding $false
$linea = "06/02/2026 14:00:10;JAVIER L.;LOZA;30;Medidor LCR / RS Pro LCR1701 / ESCFJ000970;Devoluci$([char]0xF3)n;Cerrada"
[System.IO.File]::AppendAllText("C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\HistorialCompleto.csv", "$linea`r`n", $utf8NoBOM)
cd C:\ACTUM; .\GenerarDashboard.ps1
```
Resultado: 498 movimientos.

### Fixes definitivos aplicados a MonitoreoLockerTiempoReal.ps1

**1. `$ventanaSeg = 10` → `$ventanaSeg = 3`**
- Con 10s el dedup cross-batch eliminaba eventos reales (gap de 16s ya ocurrio en may-21)
- ACTUM emite pares 10000+10001 en <2s de separacion → 3s es suficiente y seguro

**2. SAFETY NET reescrito (linea 269)**
- Problema: usaba `$fila['x'] -ne [DBNull]::Value` que puede fallar con DataRows boxeados como `object`
- Fix: usa `[string]$fila['x']` — en PowerShell el cast de DBNull a string da `""` directamente
- Usa lista separada `$safeList` en vez de `$nuevosMovimientos +=` para evitar problemas de scope
- Asigna `$nuevosMovimientos = $safeList` al final si hay resultados

**3. Else branch marcador — ya NO avanza (linea 434)**
- Antes: si `$eventosEnSQL > 0` pero `$nuevosMovimientos = 0`, avanzaba marcador al ultimo evento SQL
- Ahora: marcador NUNCA se actualiza cuando no hay movimientos nuevos
- Efecto: los artefactos se re-procesan cada minuto (siempre deduplicados) pero ningun evento real puede quedar excluido permanentemente
- Un evento solo queda excluido de la query cuando se ha escrito correctamente al CSV

**Verificacion en locker:**
```
MonitoreoLockerTiempoReal.ps1:130:        $ventanaSeg = 3
MonitoreoLockerTiempoReal.ps1:434:    # Marcador NO se actualiza cuando no hay movimientos nuevos.
```

### Regla permanente aprendida

> **El marcador NUNCA debe avanzar al timestamp de un evento que no se haya escrito al CSV.**
> Avanzar el marcador cuando `$eventosEnSQL > 0` pero `$nuevosMovimientos = 0` era el origen de todos los eventos perdidos: el marcador quedaba en T_evento, y `FechaHora > T_evento` lo excluia en adelante.

---

## Resumen de Sesion — 2026-06-02 (Bug secundario 3a ocurrencia + SAFETY NET)

### Problema: Devolucion de consigna 29 no registrada

**Sintoma:** IKER L. LASSO devolvio consigna 29 (Cal.pro. y gen.sen. / RSPRO135 / 23200551) a las 11:36:54 pero no aparecia en el dashboard. El instrumento seguia mostrando "En uso".

**Diagnostico:**
- SQL `Eventos`: evento `06/02/2026 11:36:54`, Evento=10001, Consigna=29, Usuario=8 — presente en SQL
- CSV: ultimo movimiento era `06/02/2026 11:30:08` (consigna 28) — el de consigna 29 no estaba
- Marcador `UltimoEventoProcesado.txt`: `2026-06-02 11:36:54` — habia avanzado exactamente al timestamp del evento perdido
- Estado SQL consigna 29: Estado=2 (Libre) — confirmaba que era una Devolucion

**Causa raiz — bug secundario (3a ocurrencia):**
El script encontro el evento en SQL (`$eventosEnSQL=1`), paso el dedup, pero `$nuevosMovimientos` quedo = 0 sin error ni mensaje. El bloque "todos deduplicados" (lineas 396-402) avanzo el marcador al timestamp del evento, ocultandolo permanentemente.

**Mecanismo exacto del bug:**
- Cuando `$filasLimpias` tiene datos pero PASO 4 (Group-Object/DataRow pipeline) produce 0 movimientos, el script cae al else branch con `$eventosEnSQL > 0`
- Ese branch esta disenado para eventos genuinamente deduplicados (artefactos 10000+10001)
- Pero cuando es el bug, el marcador avanza igual y el evento queda perdido para siempre

**Fix manual aplicado:**
```powershell
$utf8NoBOM = New-Object System.Text.UTF8Encoding $false
$linea = "06/02/2026 11:36:54;IKER L.;LASSO;29;Cal.pro. y gen.se$([char]0xF1). / RSPRO135 / 23200551;Devoluci$([char]0xF3)n;Cerrada"
[System.IO.File]::AppendAllText("C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\HistorialCompleto.csv", "$linea`r`n", $utf8NoBOM)
cd C:\ACTUM; .\GenerarDashboard.ps1
```
Resultado: 497 movimientos, consigna 29 muestra Disponible.

### Fix definitivo: SAFETY NET en MonitoreoLockerTiempoReal.ps1

**Bloque anadido entre PASO 4 y PASO 5** (despues del sort de $nuevosMovimientos):

```powershell
# SAFETY NET: si filasLimpias tiene datos pero nuevosMovimientos quedo vacio -> bug secundario
if ($filasLimpias.Count -gt 0 -and $nuevosMovimientos.Count -eq 0) {
    Write-Host "[SAFETY] Bug secundario detectado ($($filasLimpias.Count) filas perdidas) - procesando directamente" -ForegroundColor Magenta
    foreach ($fila in $filasLimpias) {
        # Determina accion desde estado SQL actual (Estado=2 -> Devolucion, Estado=4 -> Extraccion)
        # Es correcto para el caso tipico (1 evento perdido)
        ...
    }
}
```

**Como funciona:**
- Detecta exactamente el patron del bug: `$filasLimpias.Count > 0` AND `$nuevosMovimientos.Count = 0`
- Procesa los eventos directamente desde los datos crudos de SQL, determinando la accion por el estado actual de la consigna
- Para el caso tipico (1 evento perdido), Estado=2 → Devolucion y Estado=4 → Extraccion es siempre correcto

**Verificacion del deploy:**
```powershell
Select-String "SAFETY NET" "C:\ACTUM\MonitoreoLockerTiempoReal.ps1"
# Debe devolver: MonitoreoLockerTiempoReal.ps1:269: # SAFETY NET: ...
```

### Estado del sistema (2026-06-02 tarde):
| Componente | Estado | Notas |
|---|---|---|
| MonitoreoLockerTiempoReal | ✅ v2.2 | ventanaSeg=3, marcador conservador, SAFETY NET mejorado |
| ReconstruirCSVSemanal | ✅ Lunes 05:00 | Seguro adicional semanal |
| CSV HistorialCompleto | ✅ 498 movimientos | Completo tras fix manual consigna 30 |
| Marcador | ✅ `2026-06-02 14:00:10` | Formato correcto |

---

## Resumen de Sesion — 2026-09-07 (INCIDENTE bucle de reprocesado — RESUELTO)

> **Estado al cierre: SISTEMA REPARADO Y VERIFICADO EN PRODUCCION.** 528 movimientos, 5 tareas corriendo, cero movimientos perdidos. Quedan pendientes de PREVENCION (ver al final) — se retoman el 2026-09-08.

### Sintoma reportado

Dashboard congelado desde la noche del 12-13/08/2026. Toda la carpeta `LockerACTUM` de OneDrive parada. El 15/07 se habia verificado funcionando y se cambio la contrasena sin problema.

### VEREDICTO: NO SE PERDIO NINGUN MOVIMIENTO

**La ultima identificacion de usuario en toda la base de datos es `2026-07-16 13:20:21` (IKER L. LASSO, consigna 08).** Entre el 17/07 y el 07/09 hay **cero** identificaciones: agosto, vacaciones. No se perdieron — no los hubo.

Que el CSV se parase en el 16/07 **no era un truncamiento**: es la fecha correcta y coincide exactamente con SQL.

| Tipo de evento | N desde 01/07 | Ultimo |
|---|---|---|
| **10000** (identificacion) | 5 | **2026-07-16 13:20:21** |
| **10001** (identificacion) | 4 | **2026-07-14 13:07:06** |
| 3 (puerta cierra) | 382 | 2026-09-03 12:37:20 |
| 4 (puerta abre) | 25 | 2026-09-03 12:37:19 |

Tabla `Eventos`: **170.797 registros**, del 26/10/2024 al 03/09/2026. Histórico completo e intacto.

### Lo que si estaba destruido: el CSV

| Medida | 11/06 (sano) | 07/09 (al parar) | 07/09 (reparado) |
|---|---|---|---|
| Bytes | ~51 KB | **10.473.947** | **53.562** |
| Filas de datos | 528 | **103.494** | **528** |
| Lineas UNICAS (byte-exacto) | 528 | **187** | **528** |
| Histórico | completo | desde jun-2025, con huecos | **completo desde 26/10/2024** |
| Tildes | correctas | `IÃ‘IGO`, `DevoluciÃ³n` | **correctas** |

### CAUSA RAIZ — `MonitoreoLockerTiempoReal.ps1:436`

```powershell
# BUG: Sort-Object sin parsear -> orden ALFABETICO sobre MM/dd/yyyy
$ultimaFechaObj = [DateTime]::ParseExact(
    ($nuevosMovimientos | Sort-Object FechaHoraApertura | Select-Object -Last 1).FechaHoraApertura,
    'MM/dd/yyyy HH:mm:ss', $null)
```

Sobre `MM/dd/yyyy` el maximo **alfabetico** siempre es `12/...` -> **diciembre**. El marcador quedaba atrapado ahi.

**Confirmacion empirica en vivo:** el marcador se midio dos veces con 2h de diferencia y se vio reptar **dentro de diciembre de 2025**:
```
11:02  ->  2025-12-16 15:09:44
13:22  ->  2025-12-21 13:52:52
```
Prediccion falsable derivada: sin arreglarlo se habria estancado en un `12/31/xxxx` para siempre.

**La linea 317 del MISMO script ya lo hacia bien.** Se corrigio el sort para escribir el CSV y se dejo el roto para el marcador. Es la trampa que este documento avisaba el 2026-05-14 y que nunca se aplico a esa linea.

### Cadena completa (apagon = disparador, linea 436 = amplificador)

1. **Corte de corriente** durante el `WriteAllText` del marcador -> fichero vacio o partido
2. **Lineas 51-64** (fallback): leia `-Tail 10` del CSV y cogia **la primera linea que casaba, no la mas reciente** -> fecha antigua arbitraria
3. La query devuelve meses de eventos. **Linea 152** los procesa **agrupados por consigna, no cronologicamente** -> se appendean desordenados -> **la cola del CSV deja de ser cronologica**
4. **Linea 436** recalcula el marcador con sort alfabetico -> aterriza en diciembre 2025
5. **Bucle:** cada minuto reprocesa ~9 meses. Como la tarea muere a los 15 min de `ExecutionTimeLimit`, **nunca llega a las consignas del final** -> el historial se congela mientras el fichero engorda
6. SQL saturado -> `GenerarDashboard.ps1` empieza a fallar -> dashboard a **0/0/0** y HTML a 15 KB

**Prueba fisica de los apagones DENTRO del CSV:** 4 lineas compuestas integramente por **bytes NULL (`0x00`)**. Firma clasica de escritura interrumpida por corte de corriente.

### Cortes de corriente — 7 apagados sucios en 5 semanas

| Fecha | Evento |
|---|---|
| 03/08 11:23 y 11:59 | 6008 x2 el mismo dia |
| 04/08 05:51 | 6008 |
| 11/08 13:14 | **42 + 107** — el PC se SUSPENDIO y desperto |
| 11/08 13:16 | 6008 |
| **~12-13/08** | Se cae sucio y **nadie lo enciende -> ~19 dias muerto** |
| 31/08 11:40 | 6005 (alguien lo enciende; aqui se registra el 6008 del 12-13/08) |
| 31/08 12:07 | 1074 + 6006 + 6005 (reinicio ordenado) |
| 07/09 09:33 | 41 + 6008 + 6005 (encendido manual) |
| **07/09 13:15** | **41 + 6008 — septimo apagon, EN MEDIO del diagnostico** |

Lo que se vivio como "se apago el monitor y lo encendi" fue el PC cayendose de golpe. **No hubo evento 42 ese dia: no se durmio, es corriente.**

**El fallo caro no fue el apagon — fueron los 19 dias sin que nadie se enterase.**

### Ráfagas de eventos con Usuario=0: NO son fallos

Los picos (15/07: 180 · 03/08: 74 · 04/08: 36 · 11/08: 113 · 03/09: 38) son **aperturas manuales con llave y boton**, que abren y cierran todas las consignas a la vez. Por eso salen con `Usuario_Codigo = 0` y todas en el mismo segundo. **No son movimientos de usuario ni indican averia.** (Confirmado por Inigo, 2026-09-07.)

### SQL Server esta en ESPANOL — literales de fecha

`SELECT @@LANGUAGE` devuelve `Español` -> `DATEFORMAT dmy`. Con 4 digitos delante SQL asume ano primero y **el resto lo lee dia-mes**:

| Literal | Se interpreta como | Efecto |
|---|---|---|
| `'2026-07-01'` | ano 2026, dia 07, mes 01 = **7 de enero** | filtra mal en silencio |
| `'2026-07-16 23:59:59'` | mes **16** | error "valor fuera de intervalo" |

> **REGLA: usar SIEMPRE `'YYYYMMDD'` (`'20260701'`), neutral al idioma.** Para mostrar, `CONVERT(varchar, FechaHora, 120)`.

### EL WATCHDOG MIENTE — `GenerarDashboard.ps1:24-35`

```powershell
$tareaHTML = Get-ScheduledTask -TaskName "GenerarDashboardHTML" -ErrorAction SilentlyContinue
if ($tareaHTML -and $tareaHTML.State -eq "Disabled") {
    Enable-ScheduledTask -TaskName "GenerarDashboardHTML" -ErrorAction SilentlyContinue
    Write-Host "WATCHDOG: GenerarDashboardHTML estaba Disabled - reactivada automaticamente"
}
```

**Nunca ha funcionado.** Dos problemas encadenados:

1. **`Enable-ScheduledTask` exige Administrador**, y el proyecto obliga a que este script corra como `User` (regla del 03/03: como SYSTEM falla el SQL con Integrated Security). El `Enable` no puede funcionar en la configuracion correcta.
2. **`-ErrorAction SilentlyContinue` se come el "Acceso denegado"** y el `Write-Host` canta victoria sin comprobar. El 07/09 imprimio "reactivada automaticamente" y la tarea siguio en `Disabled` (verificado con `Get-ScheduledTask` justo despues).

> **Esto resuelve la contradiccion del documento:** una seccion decia "el watchdog la reactiva" y otra "GenerarDashboardHTML debe estar DISABLED por redundante". En la practica el watchdog no reactivaba nada.

**Antipatron que ha causado los problemas de este proyecto: declarar exito sin medir el resultado.** Fix pendiente: releer el estado tras el intento y reportar lo que realmente paso.

### Error JavaScript en OneDrive web (cosmetico)

```
Uncaught SecurityError: Failed to execute 'replaceState' on 'History' ...
origin 'null' and URL 'about:srcdoc'. (about:srcdoc:1473:95 / 1474:95)
```

Origen: `GenerarDashboard.ps1:680-681` (persistencia de pestana via hash URL, v2.1 UX del 21/04). SharePoint incrusta el HTML en un iframe `about:srcdoc` con origin `null`, donde `replaceState` con URL esta prohibido. Las lineas 680-681 del `.ps1` caen en las **1473-1474 del HTML generado**.

**No rompe los tabs** (radio buttons CSS puro), solo genera el banner rojo *"No se cargo parte del contenido"*.

> Este documento declaro ese JS "inofensivo" el 2026-06-11. **No lo es.** Fix: borrar el bloque `<script>` de las lineas 672-684.

### Tamano del DashboardLocker.html: no hay cifra "sana" fija

`GenerarDashboard.ps1` **no limita filas** (lineas 207-211): renderiza todos los movimientos tras agrupar por fecha+usuario+consigna. El tamano es **proporcional a los movimientos**:

| | Filas renderizadas | HTML |
|---|---|---|
| CSV corrupto | 103.494 filas -> **187 grupos** | 88.692 bytes |
| Reparado | 528 movimientos -> **528 grupos** | **246.461 bytes** |

`528/187 = 2,82` y `246.461/88.692 = 2,78`. El HTML era pequeno porque el `Group-Object` colapsaba las duplicadas.

> **No usar "~87 KB" como referencia de salud: esa medida se tomo en plena averia.** La referencia correcta es `<tr>` ~= movimientos + instrumentos + 2 cabeceras.

### Contadores de verificacion del HTML

- `<tr>` = **562** = 528 historial + 32 instrumentos + 2 cabeceras
- `badge-en-uso` en crudo = **17**, porque el CSS define la clase 2 veces (lineas 427 y 515). Para contar badges reales usar el patron **`badge badge-en-uso`** -> **15**

### Copia de conflicto de OneDrive

`HistorialCompleto-GHI-TAQUILLAS.csv` (10.404.324 bytes) junto al original. Copia que OneDrive crea cuando el mismo fichero cambia en dos sitios. Analizada: **las mismas 187 lineas unicas**, no aporta nada. **PENDIENTE de borrar.**

### REPARACION EJECUTADA Y VERIFICADA

| # | Accion | Verificacion medida |
|---|---|---|
| 1 | Causa raiz localizada **leyendo el codigo** | Linea 436, no inferida |
| 2 | **5 tareas desactivadas** | Las 5 en `Disabled` + `Stop-ScheduledTask` |
| 3 | **CSV congelado** | `103.495` = `103.495` en dos lecturas a 90 s |
| 4 | **Copia forense** en `C:\ACTUM\BACKUP_20260907\` | `103.495` = `103.495` filas origen vs copia |
| 5 | **Parche de 1 linea del bug raiz** (Plan B) | `PARCHE APLICADO` · 0 errores · lineas 317 y 436 parseando |
| 6 | **Auditoria de todo el repo** | 17 `Sort-Object` sobre fechas: **solo la 436 estaba rota** |
| 7 | **v2.4 desplegada por copia-pega** | **SHA256 identico** `112CE8A0…` · 517 lineas · 24.206 bytes · 0 errores · here-strings 2/2 |
| 8 | **Reconstruccion de PRUEBA** (fichero aparte) | 588 eventos -> 62 artefactos -> **526 movimientos** · unicos **526/526 = 1:1** · CSV real intacto en 10.473.947 bytes |
| 9 | **Sustitucion** | 53.381 bytes · marcador `2026-07-16 13:20:21` |
| 10 | **Consigna 22 -> SERGIO V. VEGA** reaplicada | **528** movimientos · 53.562 bytes |
| 11 | **Dashboards regenerados** | Locker 246.461 · Admin 125.404 · `En uso por SERGIO V. VEGA` · contador **528** (era 100.771) |
| 12 | **5 tareas reactivadas** | Las 5 en `Ready` |
| 13 | **PRUEBA DE FUEGO** | Tarea corriendo cada minuto durante 13 min (`LastRunTime 15:00:00`, `LastTaskResult 0`) y el CSV **sin escribirse desde las 14:47:06**. El bucle esta muerto. |

**v2.4 en produccion y en el repo, identicas:**
```
Lineas : 517      Bytes : 24.206
SHA256 : 112CE8A009E773E6888D66001FCA704089C558C41700CCC32AA9F3A497BF46A9
ASCII puro (0 caracteres no-ASCII) · here-strings 2 aperturas / 2 cierres
```

Backups de rollback en el locker: `MonitoreoLockerTiempoReal_ANTES_20260907.ps1` (v2.3 original) y `_POSTB_20260907.ps1` (v2.3 + parche B, 21.565 bytes).

### PENDIENTE — se retoma el 2026-09-08, por orden de valor

**El coste real del incidente no fue el apagon: fueron los 19 dias sin que nadie se enterase. Eso sigue sin resolver.**

- [ ] **1. ALERTA DE SISTEMA CAIDO** ← lo mas importante. Aviso automatico si el dashboard lleva >3 h sin actualizarse. Sin esto, el proximo fallo vuelve a pasar semanas desapercibido.
- [ ] **2. BIOS: `Restore on AC Power Loss -> Power On`.** 7 apagones en 5 semanas y cuando cae no vuelve solo. Requiere reiniciar el PC para entrar en la BIOS. Revisar tambien la suspension (evento 42 del 11/08 prueba que estaba activa).
- [ ] **3. Higiene rapida:**
  - Borrar `HistorialCompleto-GHI-TAQUILLAS.csv` (copia de conflicto, 10 MB inutiles)
  - Watchdog de `GenerarDashboard.ps1:24-35`: que verifique y diga la verdad
  - Borrar el `<script>` de `GenerarDashboard.ps1:672-684` (banner rojo de SharePoint)
- [ ] **4. Contrasena de `fabricacion1`** (caducaba ~26/08)
- [ ] **5. Menor:** `$estadoPorConsigna` sin definir (lineas 486-488, `EstadoAnterior.json` queda en `{}`) · revisar `$ventanaSeg = 3` (duplicados con la MISMA accion a 9-10 s en el historial antiguo) · `GHI-Locker-Dashboard/scripts/` tiene copias antiguas que difieren de la raiz

### TAREAS DE SEGUIMIENTO DEL LOCKER (apuntadas por Inigo, 2026-09-07)

Lista para retomar el tema del locker con calma — no solo el software:

- [ ] **A. PRUEBA FUNCIONAL de extraccion y devolucion.** Bajar al locker, identificarse, sacar un instrumento y devolverlo, y comprobar que el sistema lo detecta bien y en el orden correcto.
  > **Este es el hueco real de la verificacion.** Todo lo comprobado el 07/09 se hizo con datos **historicos**, porque desde el `2026-07-16 13:20:21` no hubo ningun movimiento nuevo. Que el sistema **capture correctamente un movimiento nuevo** no esta probado desde antes del incidente.
  >
  > **Predicado de exito:** por cada accion fisica aparece **1 solo movimiento** en el CSV (no 2 — ojo al dedup de `$ventanaSeg = 3` y a los pares de eventos 10000+10001), con el **usuario correcto**, la **accion correcta** (Extraccion / Devolucion segun corresponda), el **marcador avanza a la fecha de hoy** en formato `yyyy-MM-dd HH:mm:ss`, y el dashboard lo refleja en menos de 1 minuto. Verificar las tres cosas: CSV, marcador y dashboard.

- [ ] **B. AUDITORIA FISICA de las consignas.** Bajar al locker con el dashboard delante y comprobar una por una: que lo que el dashboard dice que hay en cada consigna **esta realmente ahi**, y que las marcadas como **Disponible estan vacias**. Aqui se cierra de verdad el asunto de la **consigna 22** (SERGIO VEGA vs lo que dice SQL) y cualquier otra asignacion administrativa desfasada. Referencia: las 15 consignas que el sistema da como "En uso" a 2026-09-07 son `01 02 08 09 11 13 15 19 20 21 22 24 26 27 32`.

- [ ] **C. CALIBRACIONES — ir mandando poco a poco.** Los pendientes estan apuntados en el **cuaderno GHI** y en **recordatorios del movil**. La pestana Calibracion del `DashboardAdmin.html` ya clasifica por CADUCADO / URGENTE (<30d) / PROXIMO (<90d) leyendo `Caja.FechaCaducidad` de SQL, asi que sirve directamente como lista de trabajo. **Tarea recurrente, no de un dia.**

- [ ] **D. EL ERROR QUE SALE AL ABRIR EL DASHBOARD — identificarlo de verdad.** Muy probablemente sea el banner rojo de SharePoint por `replaceState` (documentado en esta misma seccion), que se arregla borrando el `<script>` de `GenerarDashboard.ps1:672-684`. **Pero hay que confirmarlo, no darlo por hecho:** capturar el mensaje exacto cuando aparezca (`F12` -> Consola, o "Mostrar detalles" en el propio banner) por si fuera otro distinto.

### DECISION PENDIENTE — `ReconstruirCSVSemanal` borrara la correccion de la consigna 22

**El lunes 14/09 a las 05:00** esa tarea reconstruye el CSV desde SQL y **la consigna 22 volvera a salir a nombre de IKER L. LASSO**, porque las lineas de SERGIO VEGA se escriben a mano y **no existen en la tabla `Eventos`**.

Tres opciones sobre la mesa (sin decidir a 2026-09-07):
1. **Dejarlo** y reaplicar la correccion cuando pase
2. **Desactivar** la reconstruccion semanal — ya no hace falta como red de seguridad, el bug raiz esta arreglado
3. **Arreglarlo en origen:** asignar la consigna 22 a SERGIO en el ACTUM EPI Visor **y** implementar la mejora pendiente de leer `Consigna.Usuario_Codigo` para la pestana Estado. La unica que aguanta sola, pero mas trabajo

Decision de Inigo (2026-09-07): **la consigna 22 se deja a nombre de SERGIO V. VEGA**, y despues verificara fisicamente que consignas tiene quien.

Comando para reaplicar:
```powershell
$utf8NoBOM = New-Object System.Text.UTF8Encoding $false
$csv = "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\HistorialCompleto.csv"
$lineas = @(
    "04/16/2026 12:44:30;IKER L.;LASSO;22;An.gases / TESTO 340 / 63862113;Devoluci$([char]0xF3)n;Cerrada",
    "04/16/2026 12:45:00;SERGIO V.;VEGA;22;An.gases / TESTO 340 / 63862113;Extracci$([char]0xF3)n;Cerrada"
)
foreach ($l in $lineas) { [System.IO.File]::AppendAllText($csv, "$l`r`n", $utf8NoBOM) }
cd C:\ACTUM; .\GenerarDashboard.ps1
```
> Anadir lineas antiguas al final deja el CSV desordenado. **Antes del fix eso era lo que disparaba el bucle**; con v2.4 el marcador se calcula por el **maximo real** de todo el fichero, asi que ya es seguro.

### Reglas permanentes aprendidas

> **1. `Sort-Object` sobre fechas en texto `MM/dd/yyyy` ordena ALFABETICAMENTE.** Todo orden cronologico debe parsear primero: `Sort-Object { [DateTime]::ParseExact($_.Campo,'MM/dd/yyyy HH:mm:ss',$null) }`. Ha causado DOS incidentes graves (30/04 y 07/09). Auditado el repo entero el 07/09: los 17 usos restantes son correctos.

> **2. Un marcador jamas debe derivarse de la "ultima linea" de un fichero que no esta garantizado en orden cronologico.** Si hay que derivarlo, coger el **maximo parseado**, nunca la posicion.

> **3. Ratio filas/unicas es el detector barato de este fallo.** Sano ~= 1:1; el 07/09 era **~600:1**. Deberia ser un chequeo automatico. Medir con `LC_ALL=C sort -u` o `HashSet`: `sort -u` a secas usa collation de la localizacion y **falsea el conteo** en ficheros con encoding mixto (dio 166 donde habia 187).

> **4. Las dos pestanas del dashboard tienen fuentes distintas y fallan por separado.** Estado lee SQL (fiable aunque el CSV este destruido); Historial lee el CSV. Que el dashboard "se vea bien" NO prueba que el sistema este sano — **hay que mirar el contador de movimientos**. El 07/09 a las 10:57 se veia perfecto y a las 11:21 estaba a ceros.

> **5. El sistema no tiene deteccion de fallo.** Estuvo 19 dias muerto sin que nadie lo supiera. Cualquier arreglo que no incluya una alerta deja el mismo agujero abierto.

> **6. PowerShell: `$array += ...` dentro de un bucle sobre decenas de miles de filas es O(n^2)** y cuelga la consola. Usar `[System.Collections.Generic.List[T]]::new()` + `.Add()`.

> **7. Literales de fecha en SQL: SIEMPRE `'YYYYMMDD'`.** El servidor esta en espanol y `'2026-07-16'` se lee como ano-dia-mes.

> **8. `Enable-` y `Disable-ScheduledTask` exigen PowerShell como ADMINISTRADOR.** En ventana normal fallan con `Acceso denegado` (HRESULT 0x80070005). Y **`Disable-ScheduledTask` NO corta la ejecucion en marcha**: hace falta `Stop-ScheduledTask` ademas, o la instancia viva sigue hasta 15 min.

> **9. Bytes NULL (`0x00`) en un fichero de datos = escritura interrumpida por corte de corriente.** Buscarlos confirma que hubo apagon durante una escritura.

> **10. Nunca declarar exito sin releer el estado del sujeto.** El watchdog lleva meses imprimiendo "reactivada automaticamente" sin reactivar nada. Todo `Enable`/`Set`/`Copy` debe seguirse de un `Get` que lo confirme.

> **11. Desplegar por copia-pega SI es viable, con dos condiciones:** que el `.ps1` sea **ASCII puro** (ninguna codificacion puede romperlo) y **verificar SHA256 + numero de lineas + contador de here-strings (aperturas/cierres)**. Asi se desplego la v2.4 con hash identico. El fallo del 2026-03-03 (688 lineas llegaron como 454) se habria detectado al instante.

---

## Resumen de Sesion — 2026-09-08 (Prevencion: que no se caiga)

> Foco elegido por Inigo: **aparcar la alerta de caida** ("yo estoy atento cada 2 por 3") y dedicar la sesion
> a que el sistema NO se caiga. La alerta queda pendiente, sin fecha.

### 1. `ReconstruirCSVSemanal` DESACTIVADA (decision cerrada)

Se desactiva por peticion expresa: **reescribia el CSV entero desde SQL cada lunes 05:00 y borraba las
correcciones manuales** (SERGIO V. VEGA en consignas 18 y 22, y las de 13/25/29/30). Esas lineas se escriben
a mano precisamente porque **no existen en la tabla `Eventos`** — cualquier reconstruccion se las lleva por
definicion, no por fallo.

Ya no cumplia funcion: se creo el 2026-05-20 como red contra el bug de eventos perdidos, cerrado el
**04/06** (v2.3, hashtable en PASO 4) y el **07/09** (v2.4, `Sort-Object` alfabetico en `:436`).

```powershell
Disable-ScheduledTask -TaskName "ReconstruirCSVSemanal"   # requiere ADMIN
Get-ScheduledTask -TaskName "ReconstruirCSVSemanal" | Select-Object TaskName, State
```
**Verificado sobre el sujeto: `State = Disabled`.**

`ReconstruirHistorial.ps1` sigue en `C:\ACTUM\` y se lanza **a mano** cuando haga falta. Es una herramienta
de rescate, no algo que se dispare solo sobre datos buenos.

> Esto **cierra la DECISION PENDIENTE** del 07/09 sobre la consigna 22: se eligio la opcion 2 (desactivar).

### 2. Estado del sistema tras la reparacion — SANO (ver correccion en el punto 5)

| Comprobacion | Valor medido 08/09 | Lectura |
|---|---|---|
| Consigna 22 | `04/16/2026 12:45:00 SERGIO V. VEGA Extraccion` | intacta, NO hubo que reaplicar |
| Consigna 18 | `07/06/2026 08:51:08 SERGIO V. VEGA Devolucion` | devuelta de verdad el 6 de julio |
| Ratio filas/unicas | **529 / 529 = 1,00** | sano (el 07/09 era ~600:1) |
| Bytes CSV | **53.562** | **byte-identico al cierre del 07/09** |
| Marcador | `2026-07-16 13:20:21` | formato correcto, NO diciembre |

**El CSV byte-identico es la evidencia de que el bucle esta muerto.** OJO: son ~7 h de funcionamiento real,
no 24 h de calendario — el PC estuvo apagado 12 h esa noche (ver punto 5).

`ReconstruirCSVSemanal` **no corrio el 08/09**: su `LastRunTime` era `07/09/2026 5:00:00` con
`LastTaskResult 267014` (`0x41306` = *tarea finalizada por el usuario*), que son los `Stop-ScheduledTask`
de la propia reparacion. Nunca llego a reescribir nada.

> Nota de metodo: en esta sesion se dio por hecho que el 08/09 era lunes y que la reconstruccion ya habria
> corrido. **Era martes.** El dato del `LastRunTime` lo desmintio. Comprobar el dia real antes de razonar
> sobre tareas semanales.

### 3. Suspension e hibernacion DESACTIVADAS (ataca el evento 42 del 11/08)

```powershell
powercfg /change standby-timeout-ac 0
powercfg /change hibernate-timeout-ac 0
powercfg /change disk-timeout-ac 0
powercfg /hibernate off
```
**Verificado:** `Indice de configuracion de corriente alterna actual: 0x00000000` en `STANDBYIDLE` y en
`HIBERNATEIDLE`. El PC enchufado ya no se duerme solo.

`/hibernate off` desactiva ademas el *inicio rapido* de Windows -> todos los arranques son limpios.
Reversible con `/hibernate on`.

Los indices de corriente continua seguian en `0x384` (15 min) y `0x2a30` (3 h): irrelevante en un sobremesa
sin bateria, pero se igualan a 0 por si algun dia le ponen un SAI que Windows vea como bateria.

### 4. Hibernacion e inicio rapido DESACTIVADOS (verificado)

`powercfg /hibernate off` **no se habia aplicado** en el primer intento: los timeouts quedaron a 0 pero
`powercfg /a` seguia listando *Hibernar*, *Suspension hibrida* e *Inicio rapido* como **disponibles**.
Se relanzo y se reverifico:

```
No disponibles: Hibernar ("No se habilito la hibernacion") · Suspension hibrida · Inicio rapido
Disponible:     Modo de espera (S3)  <- con timeout a 0, no se activa solo
```
> Caso de libro de la regla 10: `hibernate-timeout 0` y `/hibernate off` son cosas DISTINTAS.
> Solo `powercfg /a` lo demuestra.

### 5. DIAGNOSTICO DEL PC — el disco esta sano, lo que falla es la CORRIENTE

Medido el 08/09 sobre el locker:

| Sujeto | Valor medido | Veredicto |
|---|---|---|
| Disco | KINGSTON SA400S37240G SSD · `Healthy`/`OK` · Wear 0 · 43 C · 14.447 h | **sano** |
| Espacio C: | 144,3 GB libres / 78,7 usados | **sobrado** |
| WHEA (CPU/RAM/bus) | **0 eventos en 60 dias** | **sin fallo de hardware registrado** |
| Errores disco log 30d | 4x`11` · 14x`98` · 6x`153` | **FALSA ALARMA — no son de disco (ver abajo)** |

**OCTAVO APAGON — 07/09 19:15:42**, despues de cerrar la sesion de reparacion:
```
08/09 7:59:07  6008  El cierre anterior a las 19:15:42 del 07/09/2026 resulto inesperado
```
**12 horas muerto** hasta que alguien lo encendio a mano a las 7:59.

Historial completo de caidas (log de 30 dias):

| Cierre sucio | Volvio a arrancar | Tiempo muerto |
|---|---|---|
| 11/08 13:11:24 | 11/08 13:15:55 | 4 min |
| **25/08 12:37:39** | **31/08 11:40:14** | **6 DIAS** |
| 07/09 9:27:35 | 07/09 9:33:00 | 6 min |
| 07/09 12:53:05 | 07/09 13:15:34 | 22 min |
| **07/09 19:15:42** | **08/09 7:59:00** | **12 HORAS** |

Sin patron horario. El 11/08 ademas hubo `42`+`107` (se durmio y se reanudo) — ya corregido en el punto 3-4.

**Los IDs `11` y `153` NO son de disco.** Se filtro por numero de evento sin mirar el `ProviderName`, y esos
numeros significan cosas distintas segun quien los emita:

| ID | Proveedor real | Que es | Veredicto |
|---|---|---|---|
| `11` | `Kernel-General` | Transaccion TxR del registro sobre `HarddiskVolumeShadowCopy`, resultado `0xC00000A2` (*medio protegido contra escritura*) — lo esperado sobre una instantanea, que es de solo lectura | **ruido benigno** |
| `153` | `Kernel-Boot` | "La seguridad basada en virtualizacion es disabled". Sus horas (`7:59:00`, `13:15:32`, `9:32:58`, `12:07:41`, `11:40:13`) **son exactamente los arranques** | **informativo de boot** |

> **REGLA: un Event ID sin `ProviderName` no significa nada.** `11` y `153` son de disco en `disk`/`storahci`
> y son otra cosa completamente distinta en `Kernel-General`/`Kernel-Boot`. Filtrar por numero suelto produce
> falsos positivos. Filtrar SIEMPRE por `ProviderName` + `Id`.

**Cuadro final: SSD `Healthy`, cero WHEA, cero errores de E/S reales, 144 GB libres.**

> **VEREDICTO: el PC no esta enfermo, lo estan apagando.** El dano no lo hace el corte (2 segundos), lo hace
> que **cada corte lo deja muerto hasta que alguien pasa por alli**. Por eso la BIOS
> (`Restore on AC Power Loss -> Power On`) es la accion de mayor valor de toda la lista pendiente: convierte
> 12 horas de silencio en un minuto. Un SAI atacaria la causa en vez del sintoma.

> **CORRECCION de metodo (punto 2 de esta sesion):** se afirmo que el CSV byte-identico probaba 24 h sin bucle.
> **Falso: el PC estuvo apagado 12 de esas horas.** La evidencia real son ~7 h de funcionamiento
> (07/09 14:47->19:15 y 08/09 7:59->ahora). Sigue siendo buena senal, pero la mitad de fuerte.
> Comprobar SIEMPRE el uptime antes de convertir tiempo-de-calendario en tiempo-de-observacion.

### 6. WATCHDOG ELIMINADO de `GenerarDashboard.ps1` (desplegado y verificado)

Se **elimina**, no se arregla. Tenia DOS defectos, y el segundo es el que decide:

1. **Nunca funciono.** `Enable-ScheduledTask` exige Administrador y el script debe correr como `User`
   (como SYSTEM falla el SQL, regla del 03/03). El `-ErrorAction SilentlyContinue` se tragaba el
   "Acceso denegado" y el `Write-Host` cantaba victoria igual.
2. **Su objetivo era INCORRECTO.** Intentaba reactivar `GenerarDashboardHTML`, que por arquitectura debe
   estar `Disabled` (redundante: `MonitoreoLockerTiempoReal` ya genera el HTML). Si funcionase, cada minuto
   desharia esa decision y dejaria DOS procesos escribiendo los mismos ficheros de OneDrive a la vez
   — origen probable de la copia de conflicto `HistorialCompleto-GHI-TAQUILLAS.csv`.

> **No sustituir por una version "honesta": no queremos que esa tarea se reactive.**

**Demostracion empirica del bug, del mismo dia:** el bloque original, pegado en una ventana de
**Administrador**, SI reactivo la tarea (`GenerarDashboardHTML -> Ready`). Mismo codigo, dos resultados
segun la cuenta — y el mismo mensaje de exito en ambos. Se volvio a dejar en `Disabled`.

Parche quirurgico (busca el bloque por contenido, con guarda que aborta sin tocar nada si no encaja),
backup previo en `C:\ACTUM\GenerarDashboard_ANTES_20260908.ps1`.

| Verificacion | Esperado | Medido en el locker |
|---|---|---|
| Bloque detectado | lineas 23-35 | **23-35, guarda `True`** |
| Codigo `Enable-ScheduledTask` restante | vacio | **vacio** |
| Errores de sintaxis | 0 | **0** |
| Lineas | 706 | **706** (identico al repo) |
| No-ASCII | 0 | **0** |
| Dashboard regenerado | 528 mov · ~246 KB | **528 mov · 32 instr · 246.461 bytes** |

> **El HTML salio con 246.461 bytes, byte-identico al de la reparacion del 07/09.** Salida sin cambios =
> el parche quito el watchdog sin alterar el dashboard. Ese es el predicado fuerte, mejor que "no dio error".

> **Nota:** NO se puede comparar SHA256 entre repo y locker — el repo usa LF y el locker CRLF. La
> verificacion va por propiedades (lineas · no-ASCII · sintaxis · salida byte-identica), no por huella.

> **Correccion:** se predijo `707` lineas y salieron `706`. El error era del calculo (se sumaba la linea
> vacia final); `ReadAllLines` sobre el repo da **706**. El fichero estaba bien.

### PENDIENTE tras esta sesion (reordenado por el diagnostico del punto 5)

- [ ] **1. BIOS: `Restore on AC Power Loss -> Power On`** <- AHORA ES LO PRIMERO. Es lo unico que convierte
      12 horas de silencio en un minuto. 8 apagones en 5 semanas y el PC nunca vuelve solo.
- [ ] **2. Corriente: averiguar la causa.** Como esta enchufado (regleta con interruptor? linea compartida con
      maquinaria? otros equipos que caigan a la vez?). **Un SAI ataca la causa en vez del sintoma** y con este
      historial se paga solo.
- [x] **3. Errores de disco `11`/`153` — DESCARTADO 08/09.** Falsa alarma: son `Kernel-General` (TxR sobre
      shadow copy) y `Kernel-Boot` (VBS disabled en cada arranque), no incidencias de disco. Queda solo
      confirmar el `Repair-Volume -DriveLetter C -Scan` (debe dar `NoErrorsFound`).
- [x] **4. Watchdog — ELIMINADO y verificado el 08/09** (ver punto 6).
- [ ] **5. Borrar el `<script>`** de `GenerarDashboard.ps1:672-684` (banner rojo de SharePoint por `replaceState`).
- [ ] **6. Borrar** `HistorialCompleto-GHI-TAQUILLAS.csv` (copia de conflicto, ~10 MB inutiles).
- [ ] **7. Contrasena de `fabricacion1`** (caducaba ~26/08).
- [ ] **8. Alerta de sistema caido** — aparcada por decision de Inigo, no descartada. El octavo apagon (12 h
      muertas sin que nadie se enterase) es exactamente el argumento a favor de retomarla.
- [ ] **9. Commitear v2.4 + CLAUDE.md** (ambos siguen sin commitear en el repo de desarrollo).
- [ ] **10. Tareas fisicas A-D** del 07/09. La **A** (prueba funcional real de extraccion y devolucion) sigue
      siendo el hueco de verificacion: el marcador sigue clavado en `2026-07-16 13:20:21` porque **nadie ha usado
      el locker desde entonces**, asi que el sistema reparado NO esta probado con un movimiento nuevo.

---

## AUDITORIA COMPLETA DE `C:\ACTUM` — 2026-09-08

> Sujeto: copia integra de `C:\ACTUM` del locker descargada el 08/09 a las 09:05, mas la carpeta
> `LockerACTUM` de OneDrive (descargada el 07/09 14:08, es decir **en plena averia**: su CSV son los
> 10.473.947 bytes de antes de reparar). **118 ficheros · 98 MB.**

### A. LA CADENA COMPLETA, DE LA PUERTA AL NAVEGADOR

```
[Consignas fisicas] --RS485--> [Electronica Kerong  BU 172.16.5.41:23]
        |                                   ^
        |                                   | TCP (telnet/23)
        v                                   |
[ACTUM_EPI_Gestion.exe]  <-- software del FABRICANTE, corriendo siempre
        |   escribe cada apertura/identificacion
        v
[SQL Server Express  GHI-TAQUILLAS\SQLEXPRESS  ·  BD Actum_GHI  ·  tabla Eventos]
        |
        |   <-- AQUI EMPIEZA LO NUESTRO
        v
[Task Scheduler] --> [.vbs (ventana oculta)] --> [.ps1]
        |
        v
[C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\]
   HistorialCompleto.csv · UltimoEventoProcesado.txt · DashboardLocker.html · DashboardAdmin.html
        |
        |   <-- NO hay API, NO hay subida, NO hay codigo de red.
        |       Es una CARPETA LOCAL NORMAL que el cliente OneDrive de Windows sincroniza,
        |       porque en el usuario `User` hay iniciada la sesion de fabricacion1@ghifurnaces.com
        v
[SharePoint / OneDrive de fabricacion1] --> el enlace que abre la gente en el navegador
```

> **Como se "conecta a OneDrive": no se conecta.** Los scripts escriben ficheros en una carpeta del disco
> como quien guarda en Documentos. Lo unico que la hace especial es que **OneDrive.exe la esta vigilando**
> con la cuenta `fabricacion1` autenticada. Si esa sesion caduca, los scripts siguen funcionando
> perfectamente y **nadie ve nada nuevo en la web**. Esa es la causa mas frecuente de averia del sistema
> (25/03, 06/05, 14/05) y por eso no aparece en ningun log: no es un error, es una ausencia.

**Los 3 programas del fabricante** (`C:\ACTUM\ACTUM_EPI\`):

| Programa | Para que sirve |
|---|---|
| `ACTUM_EPI_Gestion.exe` | El motor. Habla con la electronica Kerong y escribe en SQL. **Si se para, no se registra nada.** |
| `ACTUM_EPI_Visor.exe` | Consulta de estado (el "ACTUM EPI Visor" que se abre para mirar consignas) |
| `ACTUM_EPI_Parametros.exe` | Configuracion (aqui se cambio el timeout de puerta el 04/06) |

**Las 5 tareas programadas** (todas: Task Scheduler -> `wscript.exe` -> `.vbs` -> `powershell.exe -File`):

| Tarea | Cada | Script | Estado |
|---|---|---|---|
| `MonitoreoLockerTiempoReal` | 1 min | `MonitoreoLockerTiempoReal.ps1` v2.4 | activa · **es la unica imprescindible** |
| `GenerarDashboardAdmin` | 1 min | `GenerarDashboardAdmin.ps1` | activa |
| `ActualizarExcelLocker` | 5 min | `ActualizarExcel.ps1` | activa |
| `GenerarDashboardHTML` | 1 min | `GenerarDashboard.ps1` | Disabled (redundante) |
| `ReconstruirCSVSemanal` | lunes 05:00 | `ReconstruirSemanal.ps1` | Disabled el 08/09 |

`GenerarDashboard.ps1` **no necesita tarea propia**: `MonitoreoLockerTiempoReal.ps1` lo invoca con dot-sourcing
al final de cada pasada.

### B. HALLAZGO — `ReconstruirCSVSemanal` NUNCA FUNCIONO (desde el 20/05/2026)

`EjecutarReconstruccionOculto.vbs` (164 bytes) esta **partido en dos lineas**, con un `LF` suelto en mitad de
la cadena literal y la segunda linea indentada con dos espacios:

```
CreateObject("WScript.Shell").Run "powershell.exe ... -File
  ""C:\ACTUM\ReconstruirSemanal.ps1""", 0, False
```

En VBScript eso es **constante de cadena sin terminar**. Los otros cuatro `.vbs` son de UNA linea y con
`CRLF`; este es el unico con `LF` — firma de un pegado roto, exactamente el fallo que este documento
advierte sobre here-strings indentados.

**Triangulacion independiente:** si hubiera corrido alguna vez, el lunes siguiente al 10/06 habria borrado
las lineas manuales de SERGIO V. VEGA. Siguen ahi tres meses despues. **Nunca se ejecuto.**

**Y estaba roto por partida doble:** `ReconstruirSemanal.ps1` usa `Disable-ScheduledTask` /
`Enable-ScheduledTask`, que **exigen Administrador**, y la tarea corre como `User`. Aunque el VBS fuese
correcto, habria fallado igual.

> Consecuencia: la "red de seguridad semanal" documentada el 20/05 **nunca existio**. El sistema lleva
> desde junio funcionando sin ella — y sin perder nada, porque el bug raiz se cerro el 04/06.
> Su `LastTaskResult 267014` encaja: `wscript` abria un cuadro de error invisible y la tarea se quedaba
> colgada hasta el `ExecutionTimeLimit`.

### C. HALLAZGO — LOS LOGS DE ACTUM EXISTEN Y NADIE LOS MIRA

`C:\ACTUM\ACTUM_EPI\Gestion\` guarda dos series de logs del fabricante. **Son diagnostico gratis.**

**`Desconexiones_AAAAMMDD.txt`** — perdida de comunicacion con la electronica Kerong:

| Dia | Ciclos desconexion/conexion |
|---|---|
| 15/07 · 19/07 · 04/08 · 03/09 | 1 |
| 03/08 | 3 |
| **11/08** | **7 en 35 minutos** (14:22 a 14:57) |

**`Error_AAAAMMDD.txt`** — solo se crean los dias con errores. Volumen medido:

| Dia | Errores | Dia | Errores |
|---|---|---|---|
| 09/07/25 · 10/09/25 · 12/11/25 | 35-40 | 15/07/26 | 32 |
| 12/08/25 | 111 | 19/07/26 | 190 |
| 10/03 · 15/04 · 13/05 | 34-56 | **03/08/26** | **1.604** |
| | | **11/08/26** | **872** |

Un dia normal son 30-50 errores. El **03/08 (1.604)** y el **11/08 (872)** se salen de la escala, y son los
**unicos dos dias con `System.OutOfMemoryException`** en todo el historial.

Errores dominantes esos dias:
- `System.OutOfMemoryException` en `classeKerong`
- `Memoria de sistema insuficiente en el grupo de recursos de servidor internal` — **SQL Express sin RAM**
- `No hay ningun proceso en el otro extremo de la canalizacion` — **SQL Server se cayo**
- `ExecuteNonQuery requiere una Connection abierta` (688 veces el 03/08)
- `Error generico en GDI+` — agotamiento de handles

> **[RESUELTO el 08/09 - ver apartado O: es la ELECTRONICA al conectar, confirmado con firma identica]**
> ~~Hipotesis a verificar:~~ las rafagas de eventos con `Usuario_Codigo = 0`
> (03/08: 74 · 11/08: 113) se atribuyeron el 07/09 a **aperturas manuales con llave y boton**. Los logs
> ofrecen una explicacion alternativa: cuando la electronica Kerong **reconecta**, ACTUM re-lee el estado de
> todas las consignas y emite eventos de puerta en bloque. El 11/08 hubo 7 reconexiones y 113 eventos.
> **No se descarta ninguna de las dos** — hace falta comprobar si las horas de los eventos `Usuario=0`
> coinciden con las horas de `CONEXION` del log. Es una consulta de 2 minutos.

> **Pendiente de medir: cuanta RAM tiene el PC.** SQL Server Express tiene un tope propio de ~1 GB de buffer;
> si el equipo va justo de memoria, los `OutOfMemory` tienen explicacion estructural y volveran.

### D. LO QUE SOBRA — 98 MB, 118 FICHEROS, TODO EN EL MISMO CAJON

`C:\ACTUM` mezcla en la raiz: codigo en produccion, backups, datos de prueba, exports muertos, salidas de
consultas fallidas, instaladores y binarios del fabricante. Inventario de lo prescindible:

| Que | Tamano | Por que sobra |
|---|---|---|
| `Backup\*.bak` (2 ficheros de 2025) | **41 MB** | Backups SQL previos a una actualizacion de **febrero 2025** |
| `Instalador\` | **20 MB** | Instaladores `.msi`, ZNetCom, TestKerong. Utiles UNA vez |
| `Act2502\` `Act250212\` `Act250219\` | **10 MB** | Tres copias fechadas de los `.exe` del fabricante |
| `BACKUP_20260907\` | 11 MB | Copia forense de la averia. **Conservar hasta cerrar el incidente** |
| 4 backups de `MonitoreoLockerTiempoReal*.ps1` | 58 KB | `_v1_BACKUP`, `_BACKUP_20260421`, `_ANTES_20260907`, `_POSTB_20260907` |
| 3 backups de `GenerarDashboard*.ps1` | 70 KB | `_backup_20260218`, `_BACKUP_20260421`, `_ANTES_20260908` |
| `PRUEBA_HistorialCompleto.csv` + `PRUEBA_UltimoEventoProcesado.txt` | 53 KB | Restos del ensayo de reconstruccion del 07/09 |
| `ReconstruirHistorial_PRUEBA.ps1` | 9 KB | Idem |
| `UltimoEventoProcesado.txt` (en `C:\ACTUM`) | 24 B | **Leftover del 17/04 con BOM.** El real vive en OneDrive. **Trampa de diagnostico** — ya hizo perder tiempo el 30/04 |
| `Nuevo documento de texto.txt` | 0 B | Vacio |
| `tablas.txt` + `lista_tablas.txt` | 564 B | La misma lista, dos veces |
| `relaciones.txt` · `estructura_movimientos.txt` | 298 B | Salidas de consultas que devolvieron **0 filas** |
| `ejemplo_movimientos.txt` | 126 B | Un **mensaje de error de SQL** guardado como fichero |
| `EXPORT_*.txt` (8 ficheros) | 80 KB | De **febrero 2026** y con **encoding roto** (`C?mara Termogr?fica`) |
| `MoverArchivosOneDrive.ps1` | 1,5 KB | Migracion puntual de OneDrive personal a corporativo. **Ya hecha** |
| `ExportarLocker.ps1` | 2,3 KB | Escribe a `C:\Users\<user>\OneDrive\ReportesLocker` — ruta **personal que no existe**. Genera CSV pese a decir Excel |
| `Documentos - Acceso directo.lnk` | 1 KB | Acceso directo suelto |

### E. RIESGOS DETECTADOS (mas alla del desorden)

1. **Credenciales en texto plano.** `ACTUM_EPI\*\Par.txt` contiene servidor, base de datos, usuario **`sa`**
   y su contrasena en claro. Ademas los `.exe.config` llevan `User ID=sa;Password=actact` apuntando a
   **`ACTUM-JOSEP\SQLEXPRESS`** — el PC del fabricante. Esos `.config` estan obsoletos (el programa lee
   `Par.txt`), pero la credencial sigue ahi escrita. **No es accion nuestra: es del fabricante.** Anotado
   por si algun dia hay auditoria de IT.
2. **`GenerarDashboard.ps1` tiene un AUTO-UPDATE** (lineas 6-21): si aparece un `GenerarDashboard.ps1` mas
   nuevo en la carpeta de OneDrive, **lo copia a `C:\ACTUM` y lo ejecuta**. Dos caras:
   - **A favor:** es un canal de despliegue SIN TeamViewer que existe y **no se esta usando** (hoy no hay
     ningun `.ps1` en `LockerACTUM`). Subiendo el fichero por SharePoint, el locker se actualiza solo.
   - **En contra:** ejecuta lo que aparezca ahi. Si OneDrive sincroniza el fichero a medias, se ejecuta un
     script truncado. Y cualquiera con acceso a esa carpeta ejecuta codigo en el locker.
3. **El leftover `UltimoEventoProcesado.txt` de `C:\ACTUM`** no lo lee nadie hoy, pero esta a un cambio de
   ruta de convertirse en un marcador de abril. Borrarlo.
4. **El repo de desarrollo NO es espejo del locker.** Medido: `MonitoreoLockerTiempoReal.ps1` y
   `GenerarDashboard.ps1` son **identicos** (confirma que el parche del watchdog se desplego bien), pero
   `ActualizarExcel.ps1`, `ExportarLocker.ps1`, `MoverArchivosOneDrive.ps1` y `ConfigurarTareaOcultaVBS.ps1`
   **difieren**, y `GenerarDashboardAdmin.ps1` difiere solo en espacios finales.

### F. LO QUE ESTA BIEN DISENADO (no tocar)

- **La fuente de verdad es la tabla `Eventos` de SQL**, no un estado derivado. Permite reconstruir el
  historico entero desde octubre de 2024. Es la decision de arquitectura mas acertada del proyecto.
- **HTML estatico, sin JS funcional y sin CDN externos.** Es lo que lo hace visible en SharePoint web.
- **Todos los `.ps1` son ASCII puro** (medido: 0 caracteres no-ASCII en los cinco activos). Por eso el
  despliegue por copia-pega es viable.
- **El patron `.vbs` + `Run(..., 0, False)`** para ocultar la ventana funciona y esta bien documentado.
- **Un solo script imprescindible** (`MonitoreoLockerTiempoReal.ps1`) que invoca al resto por dot-sourcing.

### G. PROPUESTA — ORDEN SIN MOVER NADA QUE ESTE VIVO

> **Regla que manda aqui:** las rutas `C:\ACTUM\*.ps1` estan **cableadas en 5 ficheros `.vbs` y en 5 tareas
> programadas**. Mover un script activo obliga a reconfigurar todo eso, con riesgo real de dejar el sistema
> parado. **Los scripts activos NO se mueven.** Solo se aparta lo muerto.

```
C:\ACTUM\
├── ACTUM_EPI\                 <- del fabricante. NO TOCAR
├── MonitoreoLockerTiempoReal.ps1
├── GenerarDashboard.ps1            los 5 activos se quedan
├── GenerarDashboardAdmin.ps1       EXACTAMENTE donde estan
├── ActualizarExcel.ps1
├── ReconstruirHistorial.ps1        (rescate manual)
├── Ejecutar*.vbs  (los 4 buenos)
├── BACKUP_20260907\           <- conservar hasta cerrar el incidente
└── _ARCHIVO\                  <- NUEVA. Todo lo demas, sin borrar nada
    ├── backups_scripts\       (7 .ps1 historicos)
    ├── pruebas\               (PRUEBA_*, ReconstruirHistorial_PRUEBA.ps1)
    ├── exports_2026-02\       (EXPORT_*.txt, encoding roto)
    ├── obsoleto\              (MoverArchivosOneDrive.ps1, ExportarLocker.ps1,
    │                           ReconstruirSemanal.ps1 + su .vbs roto)
    ├── consultas_sueltas\     (tablas, lista_tablas, relaciones, estructura_*, ejemplo_*)
    └── instaladores\          (Instalador\, Act2502\, Act250212\, Act250219\, Backup\, Consignas\)
```

**Mover, no borrar** — salvo tres excepciones que si conviene eliminar:
`Nuevo documento de texto.txt` (0 bytes) · `UltimoEventoProcesado.txt` de `C:\ACTUM` (trampa de
diagnostico) · `Documentos - Acceso directo.lnk`.

**Ganancia medida:** la raiz pasa de **118 ficheros / 98 MB** a **~12 ficheros / ~17 MB** (contando
`ACTUM_EPI`), sin tocar una sola ruta de las que el sistema usa.

### H. VEREDICTO DE DISENO

**La arquitectura es correcta; lo que esta mal es la HIGIENE y la FRAGILIDAD DEL ULTIMO TRAMO.**

Lo que de verdad merece cambiarse de raiz, por orden:

1. **La dependencia de OneDrive + `fabricacion1`.** Es el unico tramo de toda la cadena que se rompe solo,
   cada ~50 dias, sin dar error. Todo lo demas (SQL, tareas, scripts) es robusto. Alternativas ya estudiadas
   el 20/05 y aun validas: **Microsoft Graph con App Registration y certificado** (no caduca nunca, sin
   coste, GHI ya tiene Entra ID) o **IIS local** sirviendo el HTML en `http://172.16.5.40` (cero cuentas,
   pendiente de verificar si las oficinas alcanzan esa subred).
2. **La falta de deteccion de fallo.** Sin respaldo humano, un fallo silencioso dura semanas. Ya paso.
3. **La higiene de `C:\ACTUM`** (apartado G).
4. **Usar el auto-update** que ya existe, para no depender de tener a alguien delante del PC.

### I. EL REPO DE DESARROLLO vs EL LOCKER — comparado el 08/09

Sujetos: `C:\ACTUM` del locker (descarga del 08/09 09:05) contra
`...\MIS PROYECTOS\LOCKER INSTRUMENTACION\`.

**Los 5 scripts activos estan alineados:**

| Fichero | Veredicto |
|---|---|
| `MonitoreoLockerTiempoReal.ps1` | **IDENTICO** byte a byte (v2.4) |
| `GenerarDashboard.ps1` | **IDENTICO** byte a byte (ya sin watchdog) |
| `ReconstruirHistorial.ps1` | **IDENTICO** |
| `GenerarDashboardAdmin.ps1` | equivalente — difiere solo en espacios finales de linea |
| `ActualizarExcel.ps1` | equivalente — solo espacios |

> Que los dos primeros salgan identicos es **verificacion independiente de los dos despliegues** de estos
> dias (v2.4 el 07/09 y watchdog el 08/09): no es que el parche dijera que fue bien, es que el fichero de
> produccion y el del repo son el mismo.

**Corregido el 08/09 — los `.vbs` no estaban respaldados:**
`EjecutarDashboardOculto.vbs`, `EjecutarAdminOculto.vbs` y `EjecutarExcelOculto.vbs` existian **solo en el
locker**; y `EjecutarMonitoreoOculto.vbs` del repo estaba **anticuado** (le faltaban `-NoProfile` y
`-WindowStyle Hidden`, que si tiene el de produccion). Copiados los 4 desde el locker: **verificado
IDENTICO** en los cuatro.

**`EjecutarReconstruccionOculto.vbs` NO se ha llevado al repo a proposito** — esta roto (apartado B) y su
tarea desactivada. Que no vuelva por la puerta de atras.

**Diferencia real que queda (sin importancia):** `ExportarLocker.ps1` difiere en 60 lineas entre ambos.
Es el script obsoleto que escribe a una ruta de OneDrive personal inexistente; va a `_ARCHIVO`.

### J. TRAMPAS DE DATOS EN EL REPO (no son produccion, pero lo parecen)

| Fichero en el repo | Que es realmente |
|---|---|
| `HistorialCompleto.csv` | **18 movimientos**, de 07/11/2025 a **17/02/2026**. Foto de hace 7 meses |
| `DashboardLocker.html` | Generado el **18/02/2026** |
| `Downloads\LockerACTUM\` (la descarga del 07/09 14:08) | CSV de **10.473.947 bytes** = la foto **EN PLENA AVERIA**, NO el estado actual |

Ninguno se usa. El sistema real vive en `C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM\`
**del locker**. Pero se llaman igual que los de produccion: quien abra la carpeta dentro de unos meses puede
tomarlos por buenos. **Renombrar con sufijo `_MUESTRA_2026-02` o mover a una subcarpeta.**

### K. HALLAZGO — `ACTUM_EPI_Gestion.exe` NO ARRANCA SOLO

Medido el 08/09: `Get-CimInstance Win32_StartupCommand` filtrado por ACTUM devuelve **vacio**, y la carpeta
`Startup` del usuario tampoco lo tiene. **El motor del locker no se levanta con el PC.**

Contexto: el 08/09 el proceso no estaba corriendo y el ultimo evento en SQL era del **03/09 12:37:30** —
pero eso era **intencionado**: Inigo lo tenia cerrado a proposito mientras el sistema estaba averiado, y lo
reabrira cuando este todo arreglado. **No era una averia desatendida.**

> **Pero el riesgo estructural es real y sigue abierto:** con `ACTUM_EPI_Gestion.exe` abierto en uso normal,
> un corte de luz lo cierra, y **al volver el PC nadie lo reabre**. De poco sirve que la BIOS encienda el
> equipo si el programa que registra los movimientos se queda sin abrir. Y a diferencia del CSV,
> **lo que no se graba no se recupera**: no esta en ninguna parte.
>
> Cuando se reabra la aplicacion, dejarlo con arranque automatico (acceso directo en la carpeta `Startup`
> del usuario `User`, o clave `Run` del registro).

`Error_20260903.txt` guarda como murio la ultima vez, por si se repite:
```
14:05:10  Sin conexion / Modulo: modulGestio / Funcion: Main / Error: Error generico en GDI+
```
`Funcion: Main` = el hilo principal. Ahi se cerro el programa.

### L. CORRECCION IMPORTANTE — la pestana Estado NO lee el estado de SQL

La **regla 4** del incidente del 07/09 decia: *"Estado lee SQL (fiable aunque el CSV este destruido)"*.
**Es FALSO.** Leido en `GenerarDashboard.ps1:174-181`:

```powershell
$estado = if ($mov.Accion -like '*Extracci*') { 'En uso' } elseif ($mov.Accion -like '*Devoluci*') { 'Disponible' }
```

El estado y el usuario salen de **la ultima accion del CSV**, no de `Consigna.Estado`. De SQL solo se toma
la descripcion y el codigo del instrumento (`mapaCajas`). **Si el CSV esta mal, la pestana Estado miente.**

Consecuencias practicas:
- Un instrumento **sin ningun movimiento en el CSV no aparece** en el dashboard.
- El unico modo de saber si el dashboard dice la verdad es **compararlo contra `Consigna.Estado` de SQL**.
- Es tambien la razon de fondo de la limitacion conocida de las asignaciones administrativas.

> **La mejora pendiente desde el 20/05 (leer `Consigna.Usuario_Codigo` para la pestana Estado) es mas
> importante de lo que parecia:** no es un detalle de quien figura como usuario, es que **toda la columna
> Estado se deriva de un fichero de texto en vez de la fuente de verdad.**

### M. AUDITORIA DEL DASHBOARD — 08/09/2026 · EL DASHBOARD DICE LA VERDAD

Ejecutado `AuditarDashboard.ps1` (creado ese dia, solo lectura, tambien en el repo).

**1. CSV — SANO**

| Medida | Valor | Predicado |
|---|---|---|
| Lineas / unicas | **529 / 529** | ratio **1,00** (el 07/09 era ~600) |
| Duplicadas exactas | **0** | |
| Bytes NULL | **0** | ninguna escritura cortada por apagon |
| Mojibake / caracter de reemplazo | **0 / 0** | encoding intacto |
| Movimientos | **528** | fechas ilegibles: **0** |
| Rango real | **26/10/2024 17:50:27 -> 16/07/2026 13:20:21** | historico completo |
| Consigna 100 (sistema) | **0** | |
| Acciones | **Extraccion=264 · Devolucion=264** | alternancia coherente de punta a punta |

**2. HTML — CORRECTO**

- **562 `<tr>` = 528 movimientos + 32 instrumentos + 2 cabeceras.** Cuadra al digito.
- **15 En uso + 17 Disponible = 32.**
- **No-ASCII: 0** — la red de seguridad de encoding funciona.
- 246.461 bytes, regenerado a las 09:42:09 (las tareas corren).

**3. DASHBOARD vs `Consigna.Estado` de SQL — 32/32 COINCIDEN, 0 DISCREPAN**

> **Veredicto: lo que muestra el dashboard es verdad.** No queda ningun rastro del bucle de reprocesado
> ni de los datos corruptos.

**DOS MATICES sobre el alcance de esa verificacion (el "OK" no cubre todo):**

1. **La consigna 22 sale `OK` pero NO es un OK completo.** El script compara **solo el estado**, no el
   usuario. Ahi: SQL dice **IKER L. LASSO** y el dashboard dice **SERGIO V. VEGA**. Coinciden en *En uso*,
   difieren en quien. Es la correccion manual del 10/06, que no existe en la tabla `Eventos`.
   **Sigue pendiente de confirmacion fisica (tarea B).**
2. **En las consignas `Disponible`, `UsuarioSQL` sale vacio y `UsuarioDash` muestra un nombre. NO es un
   fallo:** el dashboard solo pinta el usuario cuando el instrumento esta *En uso*
   (`GenerarDashboard.ps1:182`); ese nombre del CSV es simplemente quien lo devolvio el ultimo, y en el HTML
   no se ve.

**Herramienta reutilizable:** `AuditarDashboard.ps1` (127 lineas · 6.259 bytes · ASCII puro · 0 errores de
sintaxis). Lanzar cuando se sospeche de los datos: `cd C:\ACTUM ; .\AuditarDashboard.ps1`.

### N. CORRECCIONES MANUALES QUE SOBREVIVEN — 2026-09-08

**Peticion de Inigo:** *"quiero que si cambio algo a mano por cualquier razon, se quede guardado,
que si lo he hecho es por algo"*.

**El problema de fondo:** las correcciones a mano y los datos automaticos vivian **en el mismo fichero**,
y ese fichero es regenerable. Una asignacion hecha desde el ACTUM EPI Visor **sin abrir el locker
fisicamente no genera evento en SQL**, asi que al reconstruir desde `Eventos` esas lineas desaparecian.
Era disciplina, no diseno: dependia de que nadie lanzase una reconstruccion.

**La solucion — separar las dos cosas:**

| Fichero | Que es | Se regenera? |
|---|---|---|
| `HistorialCompleto.csv` | Lo que dice la tabla `Eventos` | **SI** — desechable |
| `CorreccionesManuales.csv` | Lo que decide la persona | **NO** — se conserva y se reaplica |

**Implementado:** `ReconstruirHistorial.ps1` tiene un **PASO 2.5** que, antes de escribir el CSV, lee
`CorreccionesManuales.csv` y anade sus lineas al conjunto de movimientos. Como el orden final se hace por
fecha parseada, quedan en su sitio cronologico. Si el fichero no existe, se comporta como antes; si esta
mal formado, avisa en rojo y continua sin aplicarlo (nunca rompe la reconstruccion). Las fechas ilegibles
se omiten una a una con aviso.

**Formato** (`;` como delimitador, en `C:\Users\User\OneDrive - GHI...\LockerACTUM\`):
```
FechaHoraApertura;Usuario;Apellidos;Consigna;Descripcion;Accion;EstadoPuerta;Motivo
```
La columna **`Motivo` no se copia al historial**: solo documenta por que se hizo la correccion, para que
dentro de un ano se sepa. Fecha en `MM/dd/yyyy HH:mm:ss`, igual que el historial.

> **Para cambiar de usuario una consigna hacen falta DOS lineas:** la `Devolucion` del usuario equivocado
> y, unos segundos despues, la `Extraccion` del correcto. El estado se deriva de la ultima accion.

**Scripts nuevos en el repo** (los tres ASCII puro, 0 errores de sintaxis, validados con el parser):

| Script | Que hace |
|---|---|
| `CrearCorreccionesManuales.ps1` | Crea/rehace `CorreccionesManuales.csv`. Hace copia de seguridad si ya existia y **verifica leyendo el fichero escrito**, no la intencion |
| `AuditarDashboard.ps1` | Comprueba que el dashboard dice la verdad (CSV + HTML + comparacion con `Consigna.Estado`). Solo lectura |
| `ReconstruirHistorial.ps1` | Modificado: paso 2.5 |

**Contenido inicial:** las 4 lineas de SERGIO V. VEGA (consignas 18 y 22) del 10/06/2026, con su motivo.
Las correcciones de las consignas 13, 25, 29 y 30 **NO van aqui**: aquellas si existen en `Eventos` (eran
eventos reales que los bugs no capturaron), asi que una reconstruccion las recupera sola.

**DESPLEGADO Y VERIFICADO el 08/09** (246 y 76 lineas, 0 no-ASCII, 0 errores; 4 correcciones guardadas). Se copiaron `ReconstruirHistorial.ps1` y `CrearCorreccionesManuales.ps1`
a `C:\ACTUM\` y ejecutar una vez `CrearCorreccionesManuales.ps1`.

> **Ojo con las tildes:** nunca escribir `Devolucion`/`Extraccion` con tilde literal en un `.ps1`.
> `CrearCorreccionesManuales.ps1` las construye con `[char]0xF3`, como manda la regla del proyecto.

### O. RESUELTO — las rafagas de `Usuario = 0` son la ELECTRONICA, no aperturas con llave

**Confirmado el 08/09 con un caso provocado y de causa conocida.** Al abrir `ACTUM_EPI_Gestion.exe` a las
09:30 para una comprobacion, SQL registro esto:

| Momento | Causa | Eventos generados |
|---|---|---|
| **08/09 09:30:23** | **Se abre la app ACTUM (provocado por nosotros)** | `1` x**3** + `3` x**33** |
| 11/08 14:53 | Reconexion Kerong (tras la de las 14:52) | `1` x**3** + `3` x**33** |
| 07/09 13:17 | Arranque del PC tras el apagon de las 12:53 | `1` x**3** + `3` x**32** |

**Firma identica.** Cuando la electronica conecta, ACTUM re-lee el estado de todas las consignas y emite
un bloque de eventos `3` (puerta cerrada) con `Usuario_Codigo = 0`, precedido de 3 eventos `1`.

> **Esto CORRIGE lo anotado el 07/09**, donde estas rafagas se atribuyeron a *"aperturas manuales con llave
> y boton"*. La evidencia que lo descarta: **no hay ningun bloque equivalente de eventos `4` (puerta abre)**.
> Una apertura fisica con llave generaria ~32 aperturas antes de los 32 cierres. No las hay, ni el 11/08 ni
> el 07/09 ni el 08/09.

**No ensucian el historial.** Verificado el 08/09: tras el barrido de las 09:30, las ultimas lineas del CSV
seguian siendo de julio y abril. `MonitoreoLockerTiempoReal.ps1` solo procesa `Evento IN (10000, 10001)`
—identificaciones de usuario— e ignora los eventos de puerta. **No hay que hacer nada con ellas.**

> **Trampa de lectura documentada el mismo dia:** `Get-Content` sin `-Encoding UTF8` muestra
> `ExtracciÃ³n` / `DevoluciÃ³n` en PowerShell 5.1, porque lee como ANSI y un `o` acentuado en UTF-8 son dos
> bytes. **El fichero esta bien** — `AuditarDashboard.ps1`, que lee con `ReadAllText`, dio **mojibake 0**.
> Para inspeccionar el CSV a mano: `Get-Content ... -Encoding UTF8`.

> **Y que las correcciones manuales queden al final del fichero, fuera de orden cronologico, es normal.**
> Antes de la v2.4 eso disparaba el bucle (el marcador se tomaba de la ultima linea); ahora el marcador se
> calcula por el **maximo parseado** de todo el fichero, y el dashboard ordena por fecha al renderizar.
