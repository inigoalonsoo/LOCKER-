# ReconstruirHistorial.ps1
# Reconstruye HistorialCompleto.csv desde la tabla Eventos de SQL
# Usa el estado actual de Consigna.Estado como fuente de verdad.
#
# Algoritmo: para cada consigna, tomar su estado actual y recorrer sus eventos
# del mas reciente al mas antiguo asignando acciones alternadas (Extraccion/Devolucion).
# Las correcciones manuales tienen prioridad sobre las acciones inferidas desde SQL.

param([switch]$AdoptarHistorialActual, [switch]$Aplicar, [switch]$RecuperarTransaccion)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'ProteccionHistorial.ps1')

$servidor = "GHI-TAQUILLAS\SQLEXPRESS"
$baseDatos = "Actum_GHI"
$carpetaOneDrive = "C:\Users\User\OneDrive - GHI HORNOS INDUSTRIALES S.L\LockerACTUM"
$archivoHistorial = "$carpetaOneDrive\HistorialCompleto.csv"
$archivoMarcador  = "$carpetaOneDrive\UltimoEventoProcesado.txt"

$lockerMutex = Enter-LockerLock $carpetaOneDrive
try {
if ($RecuperarTransaccion) {
    Complete-LockerTransaction $carpetaOneDrive
    return
}
Assert-LockerNoPending $carpetaOneDrive
Write-Host "[RECONSTRUCCION] Iniciando..." -ForegroundColor Cyan

# ----------------------------------------------------------------------
# 1. Consultar todos los eventos tipo 10000 + estado actual de su consigna
# ----------------------------------------------------------------------
$connectionString = "Server=$servidor;Database=$baseDatos;Integrated Security=True;Connect Timeout=30"
$connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
$connection.Open()

$query = @"
SELECT E.FechaHora, E.Consigna_Codigo, E.Caja_Codigo, E.Usuario_Codigo,
       CS.CodigoCliente AS Consigna,
       CS.Estado AS EstadoActual,
       CJ.Descripcion AS CajaDescripcion,
       U.Nombre, U.Apellidos
FROM Eventos E
INNER JOIN Consigna CS ON E.Consigna_Codigo = CS.Codigo
LEFT JOIN Caja CJ ON E.Caja_Codigo = CJ.Codigo
LEFT JOIN Usuario U ON E.Usuario_Codigo = U.Codigo
WHERE E.Evento IN (10000, 10001)
  AND E.Consigna_Codigo > 0
  AND E.Consigna_Codigo <> 100
  AND CS.Activa = 1
ORDER BY E.Consigna_Codigo ASC, E.FechaHora DESC
"@

$command = $connection.CreateCommand()
$command.CommandText = $query
$command.CommandTimeout = 120

$adapter = New-Object System.Data.SqlClient.SqlDataAdapter($command)
$dt = New-Object System.Data.DataTable
$adapter.Fill($dt) | Out-Null
$connection.Close()

Write-Host "[RECONSTRUCCION] Eventos de identificacion (10000/10001) encontrados: $($dt.Rows.Count)" -ForegroundColor Cyan

# ----------------------------------------------------------------------
# 2. DEDUPLICACION por clusters
#    Un "cluster" = eventos consecutivos misma consigna+usuario separados < 30s.
#    Cluster par  -> artefacto (identificacion doble), eliminar todos.
#    Cluster impar-> conservar solo el primero (1 interaccion real).
# ----------------------------------------------------------------------
$ventanaSegundos = 60

# Primero reordenar a fecha ascendente dentro de cada consigna para agrupar correctamente
$filasOrdenadas = $dt.Rows | Sort-Object @{Expression={[int]$_['Consigna_Codigo']}}, @{Expression={[DateTime]$_['FechaHora']}}

$filasLimpias = New-Object System.Collections.Generic.List[object]
$clusterActual = New-Object System.Collections.Generic.List[object]
$clusterConsigna = -1
$clusterUsuario  = -1
$clusterUltFecha = [DateTime]::MinValue

function Close-Cluster {
    param($cluster, $destino)
    if ($cluster.Count -eq 0) { return }
    # Cluster de 1 -> conservar unico evento
    # Cluster de 2+ -> conservar solo el primero (el mas antiguo) como representante
    $destino.Add($cluster[0]) | Out-Null
}

foreach ($row in $filasOrdenadas) {
    $consigna = [int]$row['Consigna_Codigo']
    $usuario  = if ($row['Usuario_Codigo'] -ne [DBNull]::Value) { [int]$row['Usuario_Codigo'] } else { 0 }
    $fecha    = [DateTime]$row['FechaHora']

    $perteneceCluster = $false
    if ($clusterActual.Count -gt 0) {
        $diff = ($fecha - $clusterUltFecha).TotalSeconds
        if ($consigna -eq $clusterConsigna -and $usuario -eq $clusterUsuario -and $diff -le $ventanaSegundos) {
            $perteneceCluster = $true
        }
    }

    if (-not $perteneceCluster) {
        Close-Cluster $clusterActual $filasLimpias
        $clusterActual = New-Object System.Collections.Generic.List[object]
        $clusterConsigna = $consigna
        $clusterUsuario  = $usuario
    }

    $clusterActual.Add($row) | Out-Null
    $clusterUltFecha = $fecha
}
Close-Cluster $clusterActual $filasLimpias

$descartados = $dt.Rows.Count - $filasLimpias.Count
Write-Host "[DEDUP] Artefactos descartados: $descartados" -ForegroundColor Yellow
Write-Host "[DEDUP] Eventos limpios: $($filasLimpias.Count)" -ForegroundColor Cyan

# ----------------------------------------------------------------------
# 3. Procesar por consigna (fecha DESC dentro de cada consigna)
#    Partir del estado actual y alternar hacia atras.
# ----------------------------------------------------------------------
# Reordenar: consigna ASC, fecha DESC
$filasProcesar = $filasLimpias | Sort-Object @{Expression={[int]$_['Consigna_Codigo']}}, @{Expression={[DateTime]$_['FechaHora']}; Descending=$true}

$movimientos = New-Object System.Collections.Generic.List[PSObject]
$consignaActualKey = $null
$estadoSiguiente = 0

foreach ($row in $filasProcesar) {
    $consignaCod = "$($row['Consigna_Codigo'])"

    if ($consignaCod -ne $consignaActualKey) {
        # Nueva consigna -> iniciar con estado actual de SQL
        $consignaActualKey = $consignaCod
        $estadoSiguiente = [int]$row['EstadoActual']
    }

    # La accion del evento actual es la que produjo el estado "estadoSiguiente"
    if ($estadoSiguiente -eq 4) {
        $accion = "Extracci$([char]243)n"
        $estadoSiguiente = 2  # Antes de este evento, el estado era Libre
    } else {
        $accion = "Devoluci$([char]243)n"
        $estadoSiguiente = 4  # Antes de este evento, el estado era Ocupada
    }

    $fechaHora   = [DateTime]$row['FechaHora']
    $nombre      = if ($row['Nombre']    -ne [DBNull]::Value) { "$($row['Nombre'])" }    else { "" }
    $apellidos   = if ($row['Apellidos'] -ne [DBNull]::Value) { "$($row['Apellidos'])" } else { "" }
    $consCliente = if ($row['Consigna']  -ne [DBNull]::Value) { "$($row['Consigna'])" }  else { $consignaCod }
    $descripcion = if ($row['CajaDescripcion'] -ne [DBNull]::Value) { "$($row['CajaDescripcion'])" } else { "" }

    $movimientos.Add([PSCustomObject]@{
        FechaRaw          = $fechaHora
        FechaHoraApertura = $fechaHora.ToString('MM/dd/yyyy HH:mm:ss')
        Usuario           = $nombre
        Apellidos         = $apellidos
        Consigna          = $consCliente
        Descripcion       = $descripcion
        Accion            = $accion
        EstadoPuerta      = "Cerrada"
    }) | Out-Null
}

Write-Host "[RECONSTRUCCION] Movimientos procesados: $($movimientos.Count)" -ForegroundColor Cyan

# Apply validated manual differences and keep SQL cursor independent of manual dates.
$resultado = Invoke-LockerRebuild -Folder $carpetaOneDrive -AutomaticRows @($movimientos.ToArray()) -AdoptCurrent:$AdoptarHistorialActual -Preview:(-not $Aplicar)
$resultado | Select-Object Before,After,Upserts,Deleted,Marker,Preview | Format-List
$resultado.Details | Format-Table -AutoSize
if (-not $Aplicar) { Write-Host '[PREVISUALIZACION] No se ha escrito ningun dato. Anadir -Aplicar para guardar.' }
} finally { Exit-LockerLock $lockerMutex }
